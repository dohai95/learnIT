//
//  Menuview.swift
//  nihongo
//
//  Created by USER on 2021/05/03.
//

import SwiftUI

struct Menuview: View {
    var body: some View {
        VStack(alignment:.leading){
            HStack {
                Image(systemName: "person")
                    .foregroundColor(.gray)
                    .imageScale(.large)
                Text("Profile")
                    .foregroundColor(.gray)
                    .font(.headline)
            }
            .padding(.top,10)
            HStack {
                Image(systemName: "envelope")
                    .foregroundColor(.gray)
                    .imageScale(.large)
                Text("Message")
                    .foregroundColor(.gray)
                    .font(.headline)
            }
            .padding(.top,10)
            HStack {
                Image(systemName: "gear")
                    .foregroundColor(.gray)
                    .imageScale(.large)
                Text("Setting")
                    .foregroundColor(.gray)
                    .font(.headline)
            }
            .padding(.top,10)
            Spacer()
                .frame(maxWidth: .infinity,  alignment: .leading)

        }
    }
}

struct Menuview_Previews: PreviewProvider {
    static var previews: some View {
        Menuview()
    }
}
