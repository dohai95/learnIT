//
//  rowview.swift
//  nihongo
//
//  Created by USER on 2021/05/02.
//

import SwiftUI
import AVFoundation
struct rowview: View {
    var tu:tuvung
   @State private var chuyenmanhinh=false
    @State private var message:String=""
    var body: some View {
        HStack{
            Button(action: {
               chuyenmanhinh=true
                message=tu.nghia
                readme(mytext: tu.name, mylang: "ja-JA")
            }, label: {
                
                    HStack{
                    Text(tu.name)
                        .font(.system(size: 15))
                        .fontWeight(.medium)
                        
                        .padding()
                        .frame(width: 100)
                        Spacer()
                    Text(tu.kanji)
                        .font(.system(size: 15))
                        .fontWeight(.medium)
                        .padding()
                        .frame(width: 100)
                    
                   
                   
                    
                    Spacer()
                   
                        Text(tu.nghia)
                            .font(.system(size: 15))
                            .fontWeight(.medium)
                           
                            .multilineTextAlignment(.leading)
                            .padding()
                            .frame(width: 100)
                        Spacer()
                    }
               
                
            }).frame(height: 100.0)
            .sheet(isPresented: $chuyenmanhinh, content: {
                dataview(message: $message)
            })
            
            
        }
    }
    
}
func readme(mytext:String,mylang:String){
    let utterance = AVSpeechUtterance(string: mytext)
    utterance.voice=AVSpeechSynthesisVoice(language: mylang)
    utterance.rate=0.5
    let systhesizer=AVSpeechSynthesizer()
    systhesizer.speak(utterance)
    
}
struct rowview_Previews: PreviewProvider {
    static var previews: some View {
        rowview(tu: listbai26[1])//.previewLayout(.fixed(width:500, height: 100))
    }
}
