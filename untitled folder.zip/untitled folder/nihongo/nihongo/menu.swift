//
//  menu.swift
//  nihongo
//
//  Created by USER on 2021/05/07.
//

import SwiftUI

struct menucontent:View {
    var body: some View {
        ZStack{
        
           Color(UIColor(red: 33/255, green: 33/255, blue: 33/255, alpha: 1))
            VStack{
                Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/, label: {
                    /*@START_MENU_TOKEN@*/Text("Button")/*@END_MENU_TOKEN@*/
                        .background(Color.red)
                })
            }
            Spacer()
        }
        Spacer()
        
    }
    
}
struct sidemenu:View {
    let witdh:CGFloat
    let menuopened:Bool
    let togglemenu:()->Void
    var body: some View {
        ZStack{
            GeometryReader{ geometry in sidemenu22() }
                .background(Color.red.opacity(0.1))
                
                .offset(x: menuopened ? witdh:0)
                .opacity(self.menuopened ? 1:0)
                .animation(Animation.easeIn.delay(0.25))
                .onTapGesture {
                    self.togglemenu()
                }
            HStack{
                menucontent()
                    .frame(width: witdh)
                    .offset(x:menuopened ? 0:-witdh)
                    .animation(.default)
                
                
                Spacer()
        }
        }
    }
}
struct sidemenu22:View {
    
    var body: some View {
        VStack{
            
            HStack {
               
                Text("xin chao")
            }
        }
    }
}

struct menu: View {
    @State var menuopened=false
    var body: some View {
        ZStack
        {
            VStack {
          
                if !menuopened{
                Button(action: {
                    self.menuopened.toggle()
                }, label: {
                    Text("Button")
                        .foregroundColor(Color.black)
                        .frame(width: 200, height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, alignment: .center)
                        
                })
                .background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color.blue/*@END_MENU_TOKEN@*/)
                 Text("hello")
                }
                Spacer()
                
                
            }
            sidemenu(witdh: UIScreen.main.bounds.width/2, menuopened: menuopened, togglemenu: togglemenu)
        }
        
    }
    func togglemenu()  {
        menuopened.toggle()
    }
}

struct menu_Previews: PreviewProvider {
    static var previews: some View {
        menu()
    }
}
