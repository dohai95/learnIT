//
//  ContentView.swift
//  nihongo
//
//  Created by USER on 2021/05/02.
//

import SwiftUI

struct Second:View {
    @Environment(\.presentationMode) var presentatinonMode
     var name:String=""
   
    @State private var number=26
    var body: some View {
       
       
     
        VStack{
            HStack{
                Button(action: {
                    
                        presentatinonMode.wrappedValue.dismiss()

                    

                }, label: {
                    Image(systemName: "chevron.backward")
                    Text("Back")
                })
             
                Spacer()
                Text("Bài \(name)")
                
                Spacer()
                NavigationLink(
                    destination: Second(name: String(Int(name)!+1)))
                     {
                    Text("Next")
                    Image(systemName: "chevron.forward")
                        
                    
                    }
            
          
            }
            Spacer()
            if name=="26"{
               
                List(listbai26){
                tu in rowview(tu: tu)
                }
                
            }
           else if name=="27"{
               
                List(listbai27){
                tu in rowview(tu: tu)
                }
                
            }
          else  if name=="28"{
               
                List(listbai28){
                tu in rowview(tu: tu)
                }
                
            }
          else  if name=="29"{
               
                List(listbai29){
                tu in rowview(tu: tu)
                }
                
            }
          else  if name=="30"{
                
                List(listbai30){
                tu in rowview(tu: tu)
                }
                
            }
          else  if name=="31"{
                
                List(listbai31){
                tu in rowview(tu: tu)
                }
                
            }
          else  if name=="32"{
                
                List(listbai32){
                tu in rowview(tu: tu)
                }
                
            }
          else  if name=="33"{
                
                List(listbai33){
                tu in rowview(tu: tu)
                }
                
            }
          else  if name=="34"{
                
                List(listbai34){
                tu in rowview(tu: tu)
                }
                
            }
             
        }.navigationBarHidden(true)
       
        }
    }



struct ContentView: View {
    @State var showmenu=false
    var body :some View {
        let drag=DragGesture()
            .onEnded{
                if $0.translation.width < -6{
                    withAnimation{
                        self.showmenu=false
                    }
                }
            }
        return NavigationView{
            GeometryReader{geometry in
                ZStack(alignment:.leading){  mainview(showmenu: self.$showmenu).frame(width: geometry.size.width, height: geometry.size.height)
                .offset(x: self.showmenu ?geometry.size.width/2:0)
                .disabled(self.showmenu ? true:false)
                    
            
                
            if self.showmenu{
                Menuview().frame(width: geometry.size.width/2)
                    .transition(.move(edge: .leading))
                    
            }
        
       }.gesture(drag)

    .navigationBarTitle("MINANIHONGOII",displayMode: .inline)
        .navigationBarItems(leading: (Button(action: {
            withAnimation{
                self.showmenu.toggle()
            }
            
        }
            )
       {
            Image(systemName: "line.horizontal.3")
                .imageScale(.medium)
        }
        
        )
        )
            
        }
    }
         
    
}
}


struct mainview:View{
    @Binding var showmenu:Bool
        var body: some View {
          
                
                List(26..<51){row in
                    NavigationLink(
                        destination: Second(name: "\(row)"))
                         {
                            Text("Bài \(row)")
                        }
                    
                }
        }
}
        
    
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
