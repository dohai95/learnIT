//
//  nihongoApp.swift
//  nihongo
//
//  Created by USER on 2021/05/02.
//

import SwiftUI

@main
struct nihongoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
