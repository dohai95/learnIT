//
//  testlist.swift
//  nihongo
//
//  Created by USER on 2021/05/07.
//

import SwiftUI
struct manhinh2:View {
   var name:String=""
    var body: some View {
        Text(name)
    }
}
struct testlist: View {
    @State private var message:String=""
    @State private var chuyenmanhinh=false
    var body: some View {
        List{
            ForEach(listbai26){
                tu in Button(action: {
                    message=tu.nghia
                    chuyenmanhinh=true
                    
                }, label: {
                    VStack {
                        HStack {
                            Text(tu.name+" - "+tu.kanji)
                            Spacer()
                        }
                        HStack {
                            Text(tu.nghia).padding(.horizontal, 10.0)
                            Spacer()
                        }
                        
                    }
                }).sheet(isPresented: $chuyenmanhinh, content: {
                    dataview(message: $message)
                })
                
                
                }
            }
        }
    }
    

struct testlist_Previews: PreviewProvider {
    static var previews: some View {
        testlist()
    }
}
