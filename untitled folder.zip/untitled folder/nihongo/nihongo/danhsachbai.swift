//
//  danhsachbai.swift
//  nihongo
//
//  Created by USER on 2021/05/02.
//

import Foundation
struct bai:Identifiable {
    var id:Int
    var name:String
}
let danhsach=[
    bai(id: 0, name:  "Bài 1"),
    bai(id: 1, name:  "Bài 1"),
    bai(id: 2, name:  "Bài 1"),
    bai(id: 3, name:  "Bài 1"),
    bai(id: 4, name:  "Bài 1"),
    bai(id: 5, name:  "Bài 1"),
    bai(id: 6, name:  "Bài 1"),
    bai(id: 7, name:  "Bài 1"),
    bai(id: 8, name:  "Bài 1"),
    bai(id: 9, name:  "Bài 1"),
    bai(id: 10, name:  "Bài 1"),
]
