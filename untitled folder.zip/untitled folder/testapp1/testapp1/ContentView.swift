//
//  ContentView.swift
//  testapp1
//
//  Created by USER on 2021/04/23.
//

import SwiftUI

struct ContentView: View {
   @State var showalert=false
    
    var alert:Alert
    {
        //Alert(title: Text("hello"), message: Text("showalertkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkokokokokokokokokokokokokokokokokokokokkookokokokokokokokokkkkkkk"), dismissButton: .default(Text("ok")))
        Alert(title: Text("hello"))
    }
    
    var body: some View {
        VStack(spacing: 10.0){Text("HELLO")
            
            Button(action: {self.showalert=true}, label: {
            Text("click")
        }).alert(isPresented: $showalert, content: {
            self.alert
        })}
        
            

       
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
