//
//  View02.swift
//  testbuton
//
//  Created by USER on 2021/04/23.
//

import SwiftUI

struct View02: View {
    @Binding var message:String
    @Binding var chuyenview:Bool
    var body: some View {
        VStack{
            TextField("nhap du lieu", text: $message)
            Text("\(message)")
            Button(action: {
                    self.chuyenview = false}, label: {
                Text("close")
            })
            
        }
    }
}

struct View02_Previews: PreviewProvider {
    static var previews: some View {
        View02(message: .constant(""), chuyenview: .constant(false))
    }
}
