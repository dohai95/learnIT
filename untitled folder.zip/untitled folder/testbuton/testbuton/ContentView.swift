//
//  ContentView.swift
//  testbuton
//
//  Created by USER on 2021/04/23.
//

import SwiftUI

struct ContentView: View {
    @State private var name="hello"
    @State private var number=1.0
    @State private var nhietdo:Double=0
    @State private var chuyenview=false
    @State private var message:String=""
    var body: some View
    {
        VStack(spacing: 10.0)
        {
            Button(action: {chuyenview=true}, label: {
                Image(systemName: "play")
            Text("chuyen man hinh")
            }).sheet(isPresented: $chuyenview, content: {
                View02(message: self.$message, chuyenview: self.$chuyenview)
            })
            Text("\(name)")
            .padding()
            Button(action: {self.name="0"}, label: {
                Text("Button1")
            })
            Button(action: {self.name="1"}, label: {
                Text("Button2")
            })
            TextField("nhap du lieu", text: $name)
                .frame( height: 100.0)
            Stepper(value: $number, in: 1...10,step:2) {
                Text("\(number,specifier: "%.f")")}
            
            Slider(value: $nhietdo,in:0...40)
            Text("\(nhietdo,specifier: "%.1f")do c")
     
            TextField("nhap gi do", text: $message)
            
            
        }
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
