//
//  hoctiengnhatApp.swift
//  hoctiengnhat
//
//  Created by USER on 2021/05/10.
//

import SwiftUI

@main
struct hoctiengnhatApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
