//
//  ContentView.swift
//  hoctiengnhat
//
//  Created by USER on 2021/05/10.
//

import SwiftUI
struct menucontent:View {
    var body: some View {
        ZStack{
        
//          Color(UIColor(red: 33/255, green: 33/255, blue: 33/255, alpha: 1))
            HStack {
                VStack{
                    Button(action: {}, label: {
                        Text("Home")
                            .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                            .padding(.top,5)
                            .background(Color.white)
                    })
                    Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/, label: {
                        Text("Tu Vung")
                            .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                            .padding()
                            .background(Color.white)
                    })
                    
                    Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/, label: {
                        Text("Ngu Phap")
                            .background(Color.white)
                            .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    })
                    Spacer()
                }
                Spacer()
            }
            Spacer()
        }
        Spacer()
        
    }
    
}

struct sidemenu:View {
    let witdh:CGFloat
    let menuopened:Bool
    let togglemenu:()->Void
    var body: some View {
        ZStack{
            GeometryReader{ geometry in EmptyView() }
                .background(Color.white.opacity(0.5))
                .frame(width: witdh, height: 600)
                .offset(x: menuopened ? witdh/2:0)
                .opacity(self.menuopened ? 1:0)
                .animation(Animation.easeIn.delay(0.1))
                .onTapGesture {
                    self.togglemenu()
                }
            HStack{
                menucontent()
                    .frame(width: witdh, height: 500)
                    .offset(x:menuopened ? 0:-witdh)
                    .animation(.default)
                
                
                Spacer()
        }
        }
    }
}
struct ContentView: View {
    @State var menuopened=false
    var body: some View {
        NavigationView{
            ZStack{
            VStack{
                HStack{
                    Button(action: {menuopened.toggle()}, label: {
                        
                        Image(systemName: "line.horizontal.3")
                            
                            .imageScale(.large)
                    })
                    
                    Spacer()
                    Text("MINA NIHONGO II")
                    Spacer()
                }
               
                
                List(26..<51){row in
                    NavigationLink(
                        destination: Second(name:"\(row)"))
                         {
                            Text("Bài \(row)")
                        }
                    
              
                    
                }.offset(x: menuopened ? UIScreen.main.bounds.width/2:0)
                .animation(.default)
            
           Spacer()
            
        }
            
                sidemenu(witdh: UIScreen.main.bounds.width/2, menuopened: menuopened, togglemenu: togglemenu)
                
            }.navigationBarHidden(true)
           

       
   
}
    
    }
    func togglemenu()  {
        menuopened.toggle()
}
}
struct Second: View {
    @Environment(\.presentationMode) var presentatinonMode
     var name:String=""
    
   @State var menuopened=false
    @State private var number=26
   
    var body: some View {
        
        ZStack {
            
            VStack{
                HStack {
                    Button(action: {
                        menuopened.toggle()
                        
                            
                    }, label: {
                        Image(systemName: "line.horizontal.3")
                            .imageScale(.large)
                    })
                    Spacer()
                    Text("Bài \(name)")
                }
                
                   
                
                    
                if name=="26"{
                    
                        List{
                            ForEach(listbai26){
                                    tu in Button(action: {
                                        
                                    }, label: {
                                        VStack {
                                            HStack {
                                                Text(tu.name+" - "+tu.kanji)
                                                Spacer()
                                            }
                                            HStack {
                                                Text(tu.nghia).padding(.horizontal, 10.0)
                                                Spacer()
                                            }
                                            
                                        }
                                    })
                                    }
                                  
                            
                        }.offset(x: menuopened ? UIScreen.main.bounds.width/2:0)
                        .animation(.default)
                }
                
          else if name=="27"{
                
                    List{
                        ForEach(listbai27){
                                tu in Button(action: {
                                    
                                }, label: {
                                    VStack {
                                        HStack {
                                            Text(tu.name+" - "+tu.kanji)
                                            Spacer()
                                        }
                                        HStack {
                                            Text(tu.nghia).padding(.horizontal, 10.0)
                                            Spacer()
                                        }
                                        
                                    }
                                })
                                }
                              
                        
                    }.offset(x: menuopened ? UIScreen.main.bounds.width/2:0)
                    .animation(.default)
            }
          else if name=="28"{
                
                    List{
                        ForEach(listbai28){
                                tu in Button(action: {
                                    
                                }, label: {
                                    VStack {
                                        HStack {
                                            Text(tu.name+" - "+tu.kanji)
                                            Spacer()
                                        }
                                        HStack {
                                            Text(tu.nghia).padding(.horizontal, 10.0)
                                            Spacer()
                                        }
                                        
                                    }
                                })
                                }
                              
                        
                    }.offset(x: menuopened ? UIScreen.main.bounds.width/2:0)
                    .animation(.default)
            }
          else if name=="29"{
                
                    List{
                        ForEach(listbai29){
                                tu in Button(action: {
                                    
                                }, label: {
                                    VStack {
                                        HStack {
                                            Text(tu.name+" - "+tu.kanji)
                                            Spacer()
                                        }
                                        HStack {
                                            Text(tu.nghia).padding(.horizontal, 10.0)
                                            Spacer()
                                        }
                                        
                                    }
                                })
                                }
                              
                        
                    }.offset(x: menuopened ? UIScreen.main.bounds.width/2:0)
                    .animation(.default)
            }
          else if name=="30"{
                
                    List{
                        ForEach(listbai30){
                                tu in Button(action: {
                                    
                                }, label: {
                                    VStack {
                                        HStack {
                                            Text(tu.name+" - "+tu.kanji)
                                            Spacer()
                                        }
                                        HStack {
                                            Text(tu.nghia).padding(.horizontal, 10.0)
                                            Spacer()
                                        }
                                        
                                    }
                                })
                                }
                              
                        
                    }.offset(x: menuopened ? UIScreen.main.bounds.width/2:0)
                    .animation(.default)
            }
          else if name=="31"{
                
                    List{
                        ForEach(listbai31){
                                tu in Button(action: {
                                    
                                }, label: {
                                    VStack {
                                        HStack {
                                            Text(tu.name+" - "+tu.kanji)
                                            Spacer()
                                        }
                                        HStack {
                                            Text(tu.nghia).padding(.horizontal, 10.0)
                                            Spacer()
                                        }
                                        
                                    }
                                })
                                }
                              
                        
                    }.offset(x: menuopened ? UIScreen.main.bounds.width/2:0)
                    .animation(.default)
            }
          else if name=="32"{
                
                    List{
                        ForEach(listbai32){
                                tu in Button(action: {
                                    
                                }, label: {
                                    VStack {
                                        HStack {
                                            Text(tu.name+" - "+tu.kanji)
                                            Spacer()
                                        }
                                        HStack {
                                            Text(tu.nghia).padding(.horizontal, 10.0)
                                            Spacer()
                                        }
                                        
                                    }
                                })
                                }
                              
                        
                    }.offset(x: menuopened ? UIScreen.main.bounds.width/2:0)
                    .animation(.default)
            }
          else if name=="33"{
                
                    List{
                        ForEach(listbai33){
                                tu in Button(action: {
                                    
                                }, label: {
                                    VStack {
                                        HStack {
                                            Text(tu.name+" - "+tu.kanji)
                                            Spacer()
                                        }
                                        HStack {
                                            Text(tu.nghia).padding(.horizontal, 10.0)
                                            Spacer()
                                        }
                                        
                                    }
                                })
                                }
                              
                        
                    }.offset(x: menuopened ? UIScreen.main.bounds.width/2:0)
                    .animation(.default)
            }
          else if name=="34"{
                
                    List{
                        ForEach(listbai34){
                                tu in Button(action: {
                                    
                                }, label: {
                                    VStack {
                                        HStack {
                                            Text(tu.name+" - "+tu.kanji)
                                            Spacer()
                                        }
                                        HStack {
                                            Text(tu.nghia).padding(.horizontal, 10.0)
                                            Spacer()
                                        }
                                        
                                    }
                                })
                                }
                              
                        
                    }.offset(x: menuopened ? UIScreen.main.bounds.width/2:0)
                    .animation(.default)
            }
                       
                    
              
                
                Spacer()
               
                HStack{
                    Button(action: {
                        
                            presentatinonMode.wrappedValue.dismiss()

                        

                    }, label: {
                        Image(systemName: "chevron.backward")
                        Text("Back")
                    })
                 
                   
                    
                    
                    Spacer()
                    NavigationLink(
                        destination: Second(name: String(Int(name)!+1)))
                         {
                        Text("Next")
                        Image(systemName: "chevron.forward")
                            
                    }
                        }
            }.navigationBarHidden(true)
            sidemenu(witdh: UIScreen.main.bounds.width/2, menuopened: menuopened, togglemenu: togglemenu)
        }
       
        }
    func togglemenu()  {
        menuopened.toggle()
}
    
    }

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
       
    }
}

