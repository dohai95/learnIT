//
//  data1.swift
//  hoctiengnhat
//
//  Created by USER on 2021/05/10.
//

import SwiftUI

struct data1: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct data1_Previews: PreviewProvider {
    static var previews: some View {
        data1()
    }
}
