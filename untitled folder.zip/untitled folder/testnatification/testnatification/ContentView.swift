//
//  ContentView.swift
//  testnatification
//
//  Created by USER on 2021/06/19.
//

import SwiftUI
import UserNotifications
struct ContentView: View {
    var body: some View {
        VStack{
            Button("request"){
                UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]){
                    success, error in if success{
                        print("all set")
                        
                    }
                    else if let error = error{
                        print(error.localizedDescription)
                    }
                }
            }
            Button(action: {
                let content=UNMutableNotificationContent()
                content.title="feet the cat"
                content.subtitle="it looks hungry"
                content.sound=UNNotificationSound.default
                let triger=UNTimeIntervalNotificationTrigger(timeInterval: 3, repeats: false)
                let request=UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: triger)
                UNUserNotificationCenter.current().add(request)
            
            }, label: {
                Text("Button")
            })
                
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
