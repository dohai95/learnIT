//
//  testnatificationApp.swift
//  testnatification
//
//  Created by USER on 2021/06/19.
//

import SwiftUI

@main
struct testnatificationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
