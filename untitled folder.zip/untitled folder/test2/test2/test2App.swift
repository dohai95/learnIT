//
//  test2App.swift
//  test2
//
//  Created by USER on 2021/05/01.
//

import SwiftUI

@main
struct test2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
