//
//  manhinh2.swift
//  test2
//
//  Created by USER on 2021/05/01.
//

import SwiftUI

struct manhinh2: View {
    //@Binding var message:String
    var body: some View {
        VStack {
            HStack {
                Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/, label: {
                    Image(systemName: "chevron.backward")
                    Text("Back")
                })
                Spacer()
                Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/, label: {
                    Image(systemName: "chevron.forward")
                    Text("Back")
                })
                
            }
            
            Spacer()
            Text("message")
                
        }.navigationBarHidden(true)
       
        
    }
}

struct manhinh2_Previews: PreviewProvider {
    static var previews: some View {
        manhinh2()
    }
}
