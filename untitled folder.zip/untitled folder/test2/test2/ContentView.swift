//
//  ContentView.swift
//  test2
//
//  Created by USER on 2021/05/01.
//

import SwiftUI
struct Second:View {
    let name:String
    var body: some View {
        VStack{
            HStack{
                Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/, label: {
                    Image(systemName: "chevron.backward")
                    Text("Back")
                })
                Spacer()
                Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/, label: {
                    Image(systemName: "chevron.forward")
                    Text("Next")
                })
            }
            Spacer()
       Text("\(name)")
        .navigationBarHidden(true)
        }
        
    }
    
}

struct ContentView: View {
    
    let players=[
        "1",
        "2",
        "3",
    ]
    var body: some View {
        ZStack {
            NavigationView{
               
                    List(players,id:\.self){
                        player in NavigationLink(
                            destination: Second(name: player))
                        {
                          Text(player)
                        }}
                    
                }.navigationTitle("Test")
            .navigationBarTitleDisplayMode(.inline)
            manhinh2()
        }
        
        }
    }


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
