//
//  savedataApp.swift
//  savedata
//
//  Created by USER on 2021/06/03.
//

import SwiftUI

@main
struct savedataApp: App {
    @StateObject var listViewModel:ListViewModel=ListViewModel()
    var body: some Scene {
        WindowGroup {
            NavigationView{
            ListViews()
            }.environmentObject(listViewModel)
        }
    }
}
