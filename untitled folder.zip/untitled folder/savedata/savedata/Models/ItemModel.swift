//
//  ItemModel.swift
//  savedata
//
//  Created by USER on 2021/06/03.
//

import Foundation
struct ItemModel :Identifiable, Codable{
    let id:String
    let title:String
    
    let iscompleted:Bool
    
    init(id: String=UUID().uuidString, title: String, iscompleted:Bool) {
        self.id=id
        self.title=title
       
        self.iscompleted=iscompleted
    }
    func updateCompletion() -> ItemModel{
        return ItemModel(id:id, title:title, iscompleted:!iscompleted)
    }
}
//extension ItemModel {
//    static var data: [ItemModel] {
//        [
//            
//        ]
//    }
//}
//
//extension ItemModel {
//    struct Data {
//        var title: String = ""
//        var iscompleted:Bool=false
//        
//    }
//
//    var data: Data {
//        return Data(title: title, iscompleted: iscompleted)
//    }
//}
