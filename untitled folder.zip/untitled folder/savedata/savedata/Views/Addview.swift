//
//  Addview.swift
//  savedata
//
//  Created by USER on 2021/06/03.
//

import SwiftUI

struct Addview: View {
    @Environment(\.presentationMode) var presentationModel
    @EnvironmentObject var listViewModel:ListViewModel
    @State var textfieldtext:String=""
    @State var alertTitle:String=""
    @State var showAlert:Bool=false
    
    var body: some View {
        ScrollView{
            VStack {
                TextField("type something here", text: $textfieldtext)
                .padding(.horizontal)
                .frame(height: 55)
                .background(Color(#colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)))
                    .cornerRadius(10)
                Button(action: saveButtonpressed, label: {
                    Text("Save".uppercased())
                        .foregroundColor(.white)
                        .font(.headline)
                        .frame(height: 55)
                        .frame(maxWidth: .infinity)
                        .background(Color.accentColor)
                        .cornerRadius(10)
                })
            }.padding(14)
        }.navigationTitle("Add an Item")
        .alert(isPresented: $showAlert, content: getAlert)
    }
    func saveButtonpressed(){
        if textIsappropriate(){
            listViewModel.addItem(title: textfieldtext)
            presentationModel.wrappedValue.dismiss()
        }
        
    }
    func textIsappropriate() -> Bool{
        if textfieldtext.count<3{
            alertTitle="your  new todo item must be at least 3 characters"
            showAlert.toggle()
            return false
        }
        return true
    }
    func getAlert() -> Alert{
        return Alert(title: Text(alertTitle))
    }
}

struct Addview_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView{
        Addview()
        }.environmentObject(ListViewModel())
    }
}
