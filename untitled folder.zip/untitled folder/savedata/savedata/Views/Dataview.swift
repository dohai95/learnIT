//
//  Dataview.swift
//  savedata
//
//  Created by USER on 2021/06/04.
//

import SwiftUI

struct Dataview: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct Dataview_Previews: PreviewProvider {
    static var previews: some View {
        Dataview()
    }
}
