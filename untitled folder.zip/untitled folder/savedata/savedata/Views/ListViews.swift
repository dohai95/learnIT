//
//  ListViews.swift
//  savedata
//
//  Created by USER on 2021/06/03.
//

import SwiftUI

struct ListViews: View {
    @EnvironmentObject var lisViewModel:ListViewModel
    
    var body: some View {
        List{
            ForEach(lisViewModel.items){
                item in NavigationLink(
                    destination: Text(item.id)
                    ){
                    ListRowviews(item: item)}
                    .onTapGesture {
                        withAnimation(.linear){
                            lisViewModel.updateItem(item: item)
                        }
                    }
            }.onDelete(perform: lisViewModel.deleteItem)
            .onMove(perform: lisViewModel.moveItem)
        }
        .listStyle(PlainListStyle())
        .navigationTitle("Todo List📒")
        .navigationBarItems(leading: EditButton(),
                            trailing: NavigationLink(
                                destination: Addview(),
                                label: {
                                    Text("Add")
                                }))
    }
    
       
   
}

struct ListViews_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView{
        ListViews()
        }.environmentObject(ListViewModel())
    }
}


