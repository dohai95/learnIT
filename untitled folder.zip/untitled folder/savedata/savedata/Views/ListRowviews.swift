//
//  ListRowviews.swift
//  savedata
//
//  Created by USER on 2021/06/03.
//

import SwiftUI

struct ListRowviews: View {
    let item:ItemModel
    var body: some View {
        HStack {
            Image(systemName: item.iscompleted ? "checkmark.circle": "circle")
                .foregroundColor(item.iscompleted ? .green : .red)
            Text(item.title)
            Spacer()
        }.font(.title2)
        .padding(.vertical, 8)
    }
}


struct ListRowviews_Previews: PreviewProvider {
    static var item1=ItemModel(title: "first item", iscompleted: false)
    static var item2=ItemModel(title: "second item", iscompleted: true)
    static var previews: some View {
        Group{
            ListRowviews(item: item1)
            ListRowviews(item: item2)
        }.previewLayout(.sizeThatFits)
    }
}
