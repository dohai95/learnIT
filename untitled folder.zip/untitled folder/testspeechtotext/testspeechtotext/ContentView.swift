//
//  ContentView.swift
//  testspeechtotext
//
//  Created by USER on 2021/06/26.
//

import SwiftUI

struct ContentView: View {
    @State private var transcript = ""
    @State private var isRecording = false
    private let speechRecognizer = SpeechRecognizer()
    var body: some View {
        VStack {
            Button(action: {
                speechRecognizer.record(to: $transcript)
            }, label: {
                /*@START_MENU_TOKEN@*/Text("Button")/*@END_MENU_TOKEN@*/
            })
            Button(action: {speechRecognizer.stopRecording()}, label: {
                Text("Button1")
            })
           Text(transcript)
            
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
