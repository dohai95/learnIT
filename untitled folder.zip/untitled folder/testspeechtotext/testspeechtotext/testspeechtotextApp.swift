//
//  testspeechtotextApp.swift
//  testspeechtotext
//
//  Created by USER on 2021/06/26.
//

import SwiftUI

@main
struct testspeechtotextApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
