//
//  Speech.swift
//  Apptuhoc
//
//  Created by USER on 2021/06/07.
//

import Foundation
import Speech

import  AVFoundation
func readme(mytext:String,mylang:String){
    let utterance = AVSpeechUtterance(string: mytext)
    utterance.voice=AVSpeechSynthesisVoice(language: mylang)
    utterance.rate=0.3
    utterance.volume=1
    let systhesizer=AVSpeechSynthesizer()
    systhesizer.speak(utterance)
    
}
