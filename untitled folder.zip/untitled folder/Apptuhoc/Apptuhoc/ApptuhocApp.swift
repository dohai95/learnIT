//
//  ApptuhocApp.swift
//  Apptuhoc
//
//  Created by USER on 2021/06/04.
//

import SwiftUI

@main

struct ApptuhocApp: App {
    
 @ObservedObject private var data = ScrumData()
    var body: some Scene {
        WindowGroup {
            NavigationView {
                ScrumsView(scrums: $data.scrums) {
                    data.save()
                }
            }
            .onAppear {
                data.load()
            }
        }
    }
}
