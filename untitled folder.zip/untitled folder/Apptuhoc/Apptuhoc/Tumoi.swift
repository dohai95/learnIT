//
//  Tumoi.swift
//  Apptuhoc
//
//  Created by USER on 2021/06/06.
//

import SwiftUI
import  AVFoundation
import Speech
import AVKit
struct Tumoi: View {
    @Binding var scrumData: DailyScrum.Data
   
   // @State private var scrum: DailyScrum!
    @Binding var kanji:String
    @Binding var tumoi:String
    @Binding var hiragana:String
    @Binding var vidu:String
    @State private var suakanji=""
    @State private var suatumoi=""
    
    let synthesizer = AVSpeechSynthesizer()
    var body: some View {
        
            ZStack {
                VStack {
                    Button(action: {speech(tag: kanji)}, label: {
                        Text(kanji)
                    })
                    Text(hiragana).padding()
                    Text(tumoi).padding()
                    Button(action: {speech(tag: vidu)}, label: {
                            Text(vidu)
                        
                    })
                    
                }
                
            }
    }
    func speech(tag:String){
        let utterance = AVSpeechUtterance(string: tag)
        utterance.voice = AVSpeechSynthesisVoice(language: "ja-JP")
        utterance.rate = 0.3
        utterance.volume=1

        
      
        synthesizer.speak(utterance)
        
    }

}

struct Tumoi_Previews: PreviewProvider {
    static var previews: some View {
        Tumoi(scrumData: .constant(DailyScrum.data[0].data), kanji:.constant("kanji"), tumoi: .constant("こんにちは"), hiragana: .constant("hiragana"), vidu: .constant("vi du"))
    }
}
