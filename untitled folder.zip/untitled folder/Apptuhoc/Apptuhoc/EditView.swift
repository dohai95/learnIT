/*
 See LICENSE folder for this sample’s licensing information.
 */

import SwiftUI

struct EditView: View {
    @Binding var scrumData: DailyScrum.Data
    @State private var newAttendee = ""
    @State private var tumoi = ""
    @State private var hiragana = ""
    @State private var vidu = ""
    @State private var recorkanji=false
    @State private var recorhira=false
    @State private var recorvidu=false
    @State private var showalert=false
    private let speechRecognizer = SpeechRecognizer()
    var body: some View {
    
//
//            Section(header: Text("")) {
//                ForEach(scrumData.attendees, id: \.self) { attendee in
//                    Text(attendee)
//                }
//                .onDelete { indices in
//                    scrumData.attendees.remove(atOffsets: indices)
//                }
                VStack {
                    VStack {
                        HStack {
                            TextField("kanji", text: $newAttendee)
                               
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                            Button(action: {
                                if recorkanji==false{
                                    speechRecognizer.record(to: $newAttendee)
                                    recorkanji=true
                                }
                                if recorkanji==true{
                                    speechRecognizer.stopRecording()
                                    recorkanji=false
                                }
                                    }
                                   , label: {
                                    if recorkanji==false
                                    {
                                        Image(systemName: "mic")
                                        
                                    }
                                    else{
                                        Image(systemName: "mic.slash")
                                    }
                            })
                        }
                       
                            TextField("hiragana", text: $hiragana)
                                
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .padding(.trailing,24
                                )
                        
                        HStack {
                            TextField("vidu", text: $vidu)
                              
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                            Button(action: {
                                    if recorvidu==false{
                                speechRecognizer.record(to: $vidu)
                                        recorvidu=true
                            }
                            if recorvidu==true{
                                speechRecognizer.stopRecording()
                                recorvidu=false
                            }}, label: {
                                
                                if recorvidu==false
                                {
                                    Image(systemName: "mic")
                                    
                                }
                                else{
                                    Image(systemName: "mic.slash")
                                }
                            })
                        }
                        TextField("nghia", text: $tumoi)
                       
                            
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .padding(.trailing,24
                            )
                        Button(action: {
                            
                            withAnimation {
                                scrumData.attendees.append(newAttendee)
                                scrumData.tumoi.append(tumoi)
                                scrumData.hiragana.append(hiragana)
                                scrumData.vidu.append(vidu)
                                newAttendee = ""
                                tumoi=""
                                hiragana=""
                                vidu=""
                            
                        }
                        }) {
                            Image(systemName: "plus.circle.fill")
                                .resizable()
                                .accessibilityLabel(Text("Add attendee")).frame(width: 50, height: 50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                        }
                        .disabled(newAttendee.isEmpty)
                    }
                   
                }.onDisappear{
                    speechRecognizer.stopRecording()
                }
                .alert(isPresented: $showalert, content: {
                    Alert(title: Text("Error"), message: Text("kanji và nghĩa không được trống "), dismissButton: .default(Text("Ok")))
                })
    }


//        .listStyle(InsetGroupedListStyle())
//    }
}

struct EditView_Previews: PreviewProvider {
    static var previews: some View {
        EditView(scrumData: .constant(DailyScrum.data[0].data))
    }
}
