/*
 See LICENSE folder for this sample’s licensing information.
 */

import SwiftUI

struct DetailView: View {
    @Binding var scrum: DailyScrum
    @State private var data: DailyScrum.Data = DailyScrum.Data()
    @State private var isPresented = false
    @State private var chuyenmanhinh=false
    @State private var chuyentumoi:String=""//nghia
    @State private var kanji:String=""//kanji
    @State private var testscreen=false
    @State private var hiragana:String=""//hiragana
    @State private var vidu:String=""//vidu
    @State private var showalert=false
    //@State private var showflashcard=false
    let colors: [Color] = [.red, .green, .blue, .orange, .pink, .purple, .yellow]
    var body: some View {
        VStack {
            ZStack {
                List {
                    
                   
                        ForEach(scrum.attendees, id: \.self) { attendee in
                            Button(action: {
                                kanji=attendee
                                chuyentumoi = scrum.tumoi[scrum.attendees.firstIndex(of: attendee)!]
                                hiragana = scrum.hiragana[scrum.attendees.firstIndex(of: attendee)!]
                                vidu = scrum.vidu[scrum.attendees.firstIndex(of: attendee)!]
                                data = scrum.data
                                chuyenmanhinh.toggle()
                            }, label: {
                                HStack {
                                    Text(attendee)//+" - "+scrum.hiragana[scrum.attendees.firstIndex(of: attendee)!]).foregroundColor(.black)
                                    Spacer()
                                    Image(systemName: "chevron.forward").foregroundColor(.black)
                                }
                            })
                            .sheet(isPresented: $chuyenmanhinh, content: {
                                NavigationView{
                                    Tumoi(scrumData: $data,kanji: $kanji, tumoi: $chuyentumoi, hiragana:$hiragana
                                          , vidu:$vidu).navigationBarItems(leading: Button("Back"){
                                            
                                        chuyenmanhinh=false
                                            
                                           
                                    })
                                    }
                                
                            }
                            )

                        }.onDelete{indices in scrum.attendees.remove(atOffsets: indices)}
                        
                    
                    
                }
                //.opacity(showflashcard ? 0:1)
                
                .listStyle(InsetGroupedListStyle())
                .navigationBarItems(trailing: Button("Add") {
                    isPresented = true
                    data = scrum.data
                })
                .navigationTitle(scrum.title)
                .fullScreenCover(isPresented: $isPresented) {
                    NavigationView {
                        EditView(scrumData: $data)
                            .navigationTitle(scrum.title)
                            .navigationBarItems(leading: Button("Cancel") {
                                isPresented = false
                            }, trailing: Button("Done") {
                                isPresented = false
                                scrum.update(from: data)
                            })
                    }
            }
//                GeometryReader { fullView in
//                    ScrollView(.horizontal, showsIndicators: false) {
//                        HStack {
//                            ForEach(0..<50) { index in
//                                GeometryReader { geo in
//                                    Rectangle()
//                                        .fill(self.colors[index % 7])
//                                        .frame(height: 150)
//                                        .rotation3DEffect(.degrees(-Double(geo.frame(in: .global).midX - fullView.size.width / 2) / 10), axis: (x: 0, y: 1, z: 0))
//                                }
//                                .frame(width: 150,height:150)
//                            }
//                        }
//                        .padding(.horizontal, (fullView.size.width - 150) / 2)
//                        .padding(.top,UIScreen.main.bounds.height/2.5)
//                    }
//                }
            }
            
            HStack {
                Button(action: {testscreen.toggle()
                    data=scrum.data
                    if scrum.attendees.count<4{
                        showalert.toggle()
                    }
                }, label: {
                    Text("Test")
                        .font(.title)
                        .fontWeight(.bold)
                        .frame(width: 100, height: 40, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                }).fullScreenCover(isPresented: $testscreen) {
                    if scrum.attendees.count>=4
                    {NavigationView{
                        Randomtumoi(scrumData: $data).navigationBarItems(leading: Button("Back"){
                            testscreen=false
                        })
                    }
                    }
                    
                }
                
                .alert(isPresented: $showalert, content: {
                    Alert(title: Text("Thông báo"), message: Text("Số từ phải lớn hơn 3 để Test"), dismissButton: .default(Text("OK")))
            })
               // Spacer()
//                Button(action: {showflashcard=true}, label: {
//                    Text("FlashCard").font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/).fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/).frame(width: 200, height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
//                })
            }
        }
    }
    func binding(tag:String)->String{
        kanji=tag
        return kanji
    }
   
    
}

struct DetailView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            DetailView(scrum: .constant(DailyScrum.data[0]))
        }
    }
}
