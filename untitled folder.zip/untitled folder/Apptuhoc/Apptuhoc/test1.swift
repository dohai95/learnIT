//
//  test1.swift
//  Apptuhoc
//
//  Created by USER on 2021/06/19.
//

import SwiftUI

struct test1: View {
    @State private var open=false
    var body: some View {
        
        ScrollView(.horizontal, showsIndicators: false) {
            HStack{
                ForEach(0..<10){
                    
                tag in
        Button(action: {open.toggle()}, label: {
            ZStack {
                Text("Button").opacity(open ? 0:1).rotation3DEffect(
                    .init(degrees: self.open ? 0:180),
                    axis: /*@START_MENU_TOKEN@*/(x: 0.0, y: 1.0, z: 0.0)/*@END_MENU_TOKEN@*/
                    
                    )
                Text("hello").opacity(open ? 1:0)
            }.background(Color.blue.frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/))
                    .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                    .foregroundColor(.white)
                    .rotation3DEffect(
                        .init(degrees: self.open ? 0:180),
                        axis: (x: 0.0, y: self.open ? 0:1.0, z: 0.0)
                        
                        )
                    .animation(/*@START_MENU_TOKEN@*/.easeIn/*@END_MENU_TOKEN@*/)
            
        })
            }
            }//.padding(.horizontal, (UIScreen.main.bounds.width - 50) / 2)
        }.edgesIgnoringSafeArea(.all)
    }
}

struct test1_Previews: PreviewProvider {
    static var previews: some View {
        test1()
    }
}
