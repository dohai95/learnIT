/*
 See LICENSE folder for this sample’s licensing information.
 */

import SwiftUI

struct EditView2: View {
    @Binding var scrumData: DailyScrum.Data
    
    @State private var newtitle = ""
    var body: some View {
        List {
                    VStack {
                        TextField("New title", text: $newtitle)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                        Button(action: {
                            withAnimation {
                                scrumData.title.append(newtitle)
                                newtitle = ""
                            }
                        }) {
                            Image(systemName: "plus.circle.fill")
                                .resizable()
                                .frame(width: 50, height: 50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                                .accessibilityLabel(Text("Add title"))
                        }
                        .disabled(newtitle.isEmpty)
                    }
                }
            
        
        .listStyle(InsetGroupedListStyle())
    }
}

struct EditView2_Previews: PreviewProvider {
    static var previews: some View {
        EditView2(scrumData: .constant(DailyScrum.data[0].data))
    }
}
