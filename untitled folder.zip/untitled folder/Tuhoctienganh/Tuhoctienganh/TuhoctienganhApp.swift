//
//  TuhoctienganhApp.swift
//  Tuhoctienganh
//
//  Created by USER on 2021/06/13.
//

import SwiftUI

@main
struct TuhoctienganhApp: App {
    
 @ObservedObject private var data = ScrumData()
    var body: some Scene {
        WindowGroup {
            NavigationView {
                Manhinhchinh(scrums: $data.scrums) {
                    data.save()
                }
            }
            .onAppear {
                data.load()
            }
        }
    }
}
