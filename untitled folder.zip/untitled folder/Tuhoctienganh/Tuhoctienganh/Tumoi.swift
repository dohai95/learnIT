//
//  Tumoi.swift
//  Apptuhoc
//
//  Created by USER on 2021/06/06.
//

import SwiftUI
import  AVFoundation
struct Tumoi: View {
    @Binding var scrumData: DailyScrum.Data
   
   
    @Binding var kanji:String
    @Binding var tumoi:String
   
    @Binding var vidu:String
    
    @State private var edit=false
    var body: some View {
        
            ZStack {
                VStack {
                    Button(action: {speech(tag: kanji)}, label: {
                        Text(kanji)
                    }).padding()
                    Text(tumoi)
                    
                    Button(action: {speech(tag: vidu)}, label: {
                        Text(vidu)
                    }).padding()
                    
                }
            }
    }
    func speech(tag:String){
        let utterance = AVSpeechUtterance(string: tag)
        utterance.voice = AVSpeechSynthesisVoice(language: "en-US")
        utterance.rate = 0.4

        let synthesizer = AVSpeechSynthesizer()
        synthesizer.speak(utterance)
    }

}

struct Tumoi_Previews: PreviewProvider {
    static var previews: some View {
        Tumoi(scrumData: .constant(DailyScrum.data[0].data), kanji:.constant("kanji"), tumoi: .constant("こんにちは"),  vidu: .constant("vi du"))
    }
}
