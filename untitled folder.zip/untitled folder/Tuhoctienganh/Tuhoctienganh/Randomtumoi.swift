//
//  Randomtumoi.swift
//  Apptuhoc
//
//  Created by USER on 2021/06/06.
//

import SwiftUI

struct Randomtumoi: View {
    @Binding var scrumData: DailyScrum.Data
   
    
   @State private var correctanswer=Int.random(in: 0...3)
    @State private var dapan:String="sai"
    @State private var cauhoi=0
    @State private var mangmoi:[String]=[""]
    @State private var alerttitle=""
    @State private var showalert=false
    @State private var start=false
    @State private var dapandung=false
    @State private var mangluutru:[String]=[]
    @State private var count=0
    @State private var kiemtra=false
    @State private var ok=0
    let colors: [Color] = [.red, .green, .blue, .orange, .pink, .purple, .yellow]
    var body: some View {
        //let randomnghia=scrumData.tumoi.shuffled()
      

           
                
            ZStack {
                
                 Button(action: {
                     start.toggle()
                     mangmoi=scrumData.tumoi.shuffled()
                    kiemtra=true
                    test()
                    
                 }, label: {
                     Text("START TEST")
                         .font(.title).fontWeight(.semibold)
                        .frame(width: 300.0, height: 100.0)
                        .background(Color.blue.cornerRadius(20).frame(width: 300, height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/))
                         .foregroundColor(.white)
                         .padding(.horizontal,20)
                         
                     
                 }).opacity(start ? 0:1)
                VStack{
                    
                    if start==true&&kiemtra==true{
                 ForEach(0..<4){
                  
                    number in Button(action: {
                        if number==correctanswer{
                            alerttitle="dung roi"
                            showalert=true
                            dapandung=true
                            mangluutru.insert(scrumData.attendees[scrumData.tumoi.firstIndex(of: mangmoi[correctanswer])!], at: count)
                            count=count+1
                           // kiemtra=false
                            if count==mangmoi.count{
                                test()
                                count=0
                            }
                        }
                        else{
                            alerttitle="sai roi"
                            showalert=true
                            dapandung=false
                        }
                    }, label: {
                       
                        Text(mangmoi[number])
                            .font(.title)
                            .padding()
                            .background(Color.blue.frame(width: 300, height: 80, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/).cornerRadius(20))
                             .foregroundColor(.white)
                            
                            .frame(width: 300.0, height: 80.0)
                        

                    })
                 
                    
                  
                 }
                       
                        
                        
                    }
                        
                        
                                
                }.alert(isPresented: $showalert) {
                    Alert(title: Text(alerttitle), dismissButton: .default(Text("Ok")){
                        if dapandung==true{
                            self.askquestion()
                            
                        }
                    })
                }
                .animation(/*@START_MENU_TOKEN@*/.easeIn/*@END_MENU_TOKEN@*/)
              
                VStack{
                   // Text(String(count))
                    //Text(String(ok))
                    if start==true&&kiemtra==true
                    {
                        Text(scrumData.attendees[scrumData.tumoi.firstIndex(of: mangmoi[correctanswer])!])
                            .font(.largeTitle)
                            .fontWeight(.bold)
                            .padding()
                            
                            .frame(width: 500.0,height: 100)
                            
                            
                    Spacer()
                    }
                }.animation(/*@START_MENU_TOKEN@*/.easeIn/*@END_MENU_TOKEN@*/)
            }
            
            
          
               
                
            
           
            
        
                    
            
            
        }
    func askquestion(){
        correctanswer=Int.random(in: 0...3)
        mangmoi=scrumData.tumoi.shuffled()
        
        for  a in 0...mangmoi.count
        {
            if scrumData.attendees[scrumData.tumoi.firstIndex(of: mangmoi[correctanswer])!]==mangluutru[a]{
                ok=ok+1
            }
        }
        while ok>0 {
            correctanswer=Int.random(in: 0...3)
            mangmoi=scrumData.tumoi.shuffled()
            var b=0
            for  a in 0...mangmoi.count
            {
                if scrumData.attendees[scrumData.tumoi.firstIndex(of: mangmoi[correctanswer])!]==mangluutru[a]{
                    b=b+1
                }
                
            }
            if b==0{
                ok=0
            }
        }
          
    }
            
    
    func test(){
        for a in 0..<scrumData.attendees.count{
            mangluutru.insert(" ", at: a)
        }
    }
    }
    
    


struct Randomtumoi_Previews: PreviewProvider {
    static var previews: some View {
        Randomtumoi(scrumData: .constant(DailyScrum.data[0].data))
    }
}

