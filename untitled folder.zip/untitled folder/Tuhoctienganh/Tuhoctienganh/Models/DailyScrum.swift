/*
See LICENSE folder for this sample’s licensing information.
*/
import SwiftUI

struct DailyScrum: Identifiable, Codable {
    let id: UUID
    var title: String
    var attendees: [String]
    var tumoi:[String]
    //var color: Color
    var history: [History]
    //var hiragana:[String]
    var vidu:[String]

    init(id: UUID = UUID(), title: String, attendees: [String], tumoi:[String], history: [History] = [],  vidu:[String]) {
        self.id = id
        self.title = title
        self.attendees = attendees
        self.tumoi=tumoi
        
        self.history = history
        //self.hiragana=hiragana
        self.vidu=vidu
    }
}

extension DailyScrum {
    static var data: [DailyScrum] {
        [
            DailyScrum(title: "DAY 1", attendees: ["私", "Daisy", "Simon", "Jonathan","a","b","c","d"], tumoi: ["11111111","2","3","4","5","6","7","8"], vidu:["vidu","333"]),
            DailyScrum(title: "DAY 2", attendees: ["Katie", "Gray", "Euna", "Luis", "Darla"], tumoi: ["1","2"],  vidu:[]),
            DailyScrum(title: "DAY 3", attendees: ["Chella", "Chris", "Christina", "Eden", "Karla", "Lindsey", "Aga", "Chad", "Jenn", "Sarah"], tumoi: ["1","2"],  vidu:[] )
        ]
    }
}

extension DailyScrum {
    struct Data {
        var title: String = ""
        var attendees: [String] = []
       var tumoi:[String]=[]
        //var hiragana:[String]=[]
        var vidu:[String]=[]
        
    }

    var data: Data {
        return Data(title: title, attendees: attendees,tumoi:tumoi, vidu: vidu)
    }

    mutating func update(from data: Data) {
        title = data.title
        attendees = data.attendees
        tumoi=data.tumoi
        
        vidu=data.vidu
    }
}
