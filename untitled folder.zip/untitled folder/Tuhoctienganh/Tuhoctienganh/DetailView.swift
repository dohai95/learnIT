/*
 See LICENSE folder for this sample’s licensing information.
 */

import SwiftUI

struct DetailView: View {
    @Binding var scrum: DailyScrum
    @State private var data: DailyScrum.Data = DailyScrum.Data()
    @State private var isPresented = false
    @State private var chuyenmanhinh=false
    @State private var chuyentumoi:String=""//nghia
    @State private var kanji:String=""//kanji
    @State private var testscreen=false
   
    @State private var vidu:String=""//vidu
    @State private var showalert=false
    
    
    var body: some View {
        VStack {
            List {
                
               
                    ForEach(scrum.attendees, id: \.self) { attendee in
                        Button(action: {
                            kanji=attendee
                            chuyentumoi = scrum.tumoi[scrum.attendees.firstIndex(of: attendee)!]
                            
                            vidu = scrum.vidu[scrum.attendees.firstIndex(of: attendee)!]
                            data = scrum.data
                            chuyenmanhinh.toggle()
                        }, label: {
                            HStack {
                                Text(attendee).foregroundColor(.black)
                                Spacer()
                                Image(systemName: "chevron.forward").foregroundColor(.black)
                            }
                        })
                        .sheet(isPresented: $chuyenmanhinh, content: {
                            NavigationView{
                                Tumoi(scrumData: $data,kanji: $kanji, tumoi: $chuyentumoi,  vidu:$vidu).navigationBarItems(leading: Button("Back"){
                                    chuyenmanhinh=false
                                })
                                }
                            
                        }
                        )

                    }.onDelete{indices in scrum.attendees.remove(atOffsets: indices)}
                
                
            }
            
            .listStyle(InsetGroupedListStyle())
            .navigationBarItems(trailing: Button("Add") {
                isPresented = true
                data = scrum.data
            })
            .navigationTitle(scrum.title)
            .fullScreenCover(isPresented: $isPresented) {
                NavigationView {
                    EditView(scrumData: $data)
                        .navigationTitle(scrum.title)
                        .navigationBarItems(leading: Button("Cancel") {
                            isPresented = false
                        }, trailing: Button("Done") {
                            isPresented = false
                            scrum.update(from: data)
                        })
                }
        }
            Button(action: {testscreen.toggle()
                data=scrum.data
                if scrum.attendees.count<4{
                    showalert.toggle()
                }
            }, label: {
                Text("Test")
                    .font(.title)
                    .fontWeight(.bold)
            }).fullScreenCover(isPresented: $testscreen) {
                if scrum.attendees.count>4
                {NavigationView{
                    Randomtumoi(scrumData: $data).navigationBarItems(leading: Button("Back"){
                        testscreen=false
                    })
                }
                }
                
            }
            
            .alert(isPresented: $showalert, content: {
                Alert(title: Text("thong bao"), message: Text("so tu qua it de test"), dismissButton: .default(Text("OK")))
            })
        }
    }
    func binding(tag:String)->String{
        kanji=tag
        return kanji
    }
   
    
}

struct DetailView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            DetailView(scrum: .constant(DailyScrum.data[0]))
        }
    }
}

