//
//  ContentView.swift
//  testspeech
//
//  Created by USER on 2021/06/15.
//
import  UIKit
import SwiftUI
import AVFoundation
import Foundation
import Speech
struct ContentView: View {
  
    @State private var textfield=""
    let utterance=AVSpeechUtterance(string: "hello my name is tom")
    let voice=AVSpeechSynthesisVoice(language: "en-US")
    
    var body: some View {
        VStack {
            TextField("nhap gi do", text: $textfield)
            Button(action: {
                utterance.rate=0.4
                utterance.pitchMultiplier=0.8
                utterance.postUtteranceDelay=0.2
                utterance.volume=0.8
                utterance.voice=voice
                let sysnthesizer=AVSpeechSynthesizer()
                speechsysthesizer(_sythesizer: sysnthesizer, didStart: utterance)
              sysnthesizer.speak(utterance)
                
               
                
            }, label: {
                /*@START_MENU_TOKEN@*/Text("Button")/*@END_MENU_TOKEN@*/
            })
        }
    
    }
    func speechsysthesizer(_sythesizer:AVSpeechSynthesizer, didStart utterance:AVSpeechUtterance) {
        textfield=utterance.speechString
    }
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
