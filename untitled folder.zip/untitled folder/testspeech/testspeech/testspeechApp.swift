//
//  testspeechApp.swift
//  testspeech
//
//  Created by USER on 2021/06/15.
//

import SwiftUI

@main
struct testspeechApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
