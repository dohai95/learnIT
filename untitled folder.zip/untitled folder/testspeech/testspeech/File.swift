//
//  File.swift
//  testspeech
//
//  Created by USER on 2021/06/18.
//

import Foundation
import AVKit
class SpeechService: NSObject {
   static let shared=SpeechService()
    let speechSynthesizer=AVSpeechSynthesizer()
    func startSpeech(_text:String){
        
        if let lan=NSLinguisticTagger.dominantLanguage(for: _text){
            let utterence=AVSpeechUtterance(string: _text)
            utterence.voice=AVSpeechSynthesisVoice(language: lan)
            speechSynthesizer.speak(utterence)
        }
    }
}
