//
//  testvoiceApp.swift
//  testvoice
//
//  Created by USER on 2021/04/29.
//

import SwiftUI

@main
struct testvoiceApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
