//
//  dataview.swift
//  listapp
//
//  Created by USER on 2021/04/29.
//

import SwiftUI

struct dataview: View {
    @Binding var message:String
    
    
    var body: some View {
        Text(message)
    }
}

struct dataview_Previews: PreviewProvider {
    static var previews: some View {
        dataview(message:.constant(""))
        
    }
}
