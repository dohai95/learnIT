//
//  Food.swift
//  listapp
//
//  Created by USER on 2021/04/28.
//

import Foundation
struct tuvung:Identifiable {
    var id:Int
    var name:String
    var kanji:String
    var nghia:String
    
}
let listbai26=[
    tuvung(id: 0, name: "みます", kanji: "見ます", nghia: "nhìn, xem, khám bệnh"),
    tuvung(id: 1, name: "さがします", kanji: "探します、捜します", nghia: "tìm kiếm"),
    tuvung(id: 2, name: "おくれます", kanji: "遅れます", nghia: "chậm,muộn"),
    tuvung(id: 4, name: "まにあいます", kanji: "間に合います", nghia: "kịp giờ, cuộc hẹn"),
    tuvung(id: 5, name: "やります", kanji: "", nghia: "làm"),
    tuvung(id: 6, name: "さんかします", kanji: "参加します", nghia: "tham gia"),
    tuvung(id: 7, name: "もうしこみます", kanji: "申し込みます", nghia: "đăng ký"),
    tuvung(id: 8, name: "つごうがいい", kanji: "都合がいい", nghia: "có thời gian thuận tiện"),
    tuvung(id: 9, name: "つごうがわるい", kanji: "都合が悪い", nghia: "không có thời gian thuận tiện"),
    tuvung(id: 10, name: "きぶんがい", kanji: "気分がいい", nghia: "cảm thấy khoẻ"),
    tuvung(id: 11, name: "きぶんがわるい", kanji: "気分が悪い", nghia: "cảm thấy không khoẻ"),
    tuvung(id: 12, name: "しんぶんしゃ", kanji: "新聞社", nghia: "công tý báo"),
    tuvung(id: 13, name: "じゅうどう", kanji: "柔道", nghia: "judo, nhu đạo"),
]
let listbai27=[
    tuvung(id: 0, name: "かいます", kanji: "飼います", nghia: "nuôi"),
    tuvung(id: 1, name: "たてます", kanji: "建てます", nghia: "xây dựng"),
    tuvung(id: 2, name: "はしります", kanji: "走ります", nghia: "chạy"),
    tuvung(id: 4, name: "とります", kanji: "取ります", nghia: "chụp ảnh"),
    tuvung(id: 5, name: "みえます", kanji: "見えます", nghia: "có thể nhìn thấy"),
    tuvung(id: 6, name: "きこえます", kanji: "聞こえます", nghia: "có thể nghe"),
    tuvung(id: 7, name: "できます", kanji: "出来ます", nghia: "có thể"),
    tuvung(id: 8, name: "ひらきます", kanji: "開きます", nghia: "mở(lớp học, cuộc họp)"),
    tuvung(id: 9, name: "ペット", kanji: "", nghia: "thú cưng"),
    tuvung(id: 10, name: "とり", kanji: "鳥", nghia: "chim"),
    tuvung(id: 11, name: "こえ", kanji: "声", nghia: "tiếng nói"),
    tuvung(id: 12, name: "なみ", kanji: "波", nghia: "sóng"),
    tuvung(id: 13, name: "はなび", kanji: "花火", nghia: "pháo hoa"),
]

