//
//  rowfood.swift
//  listapp
//
//  Created by USER on 2021/04/28.
//

import SwiftUI

struct rowfood: View {
    var tu:tuvung
    @State private var chuyenview=false
    @State private var message:String=""

    var body: some View {
        HStack{
            Button(action: {
                chuyenview=true
                message=tu.nghia
                readme(mytext: tu.kanji, mylang: "ja-JA")
            }, label: {
               HStack{
                Text(tu.name)
                    .font(.system(size: 15))
                    .fontWeight(.medium)
                    .padding()
                    .frame(width: 100.0)
                Text(tu.kanji)
                    .font(.system(size: 15))
                    .fontWeight(.medium)
                    .padding()
                    .frame(width: 100.0)
                Text(tu.nghia)
                    .font(.system(size: 15))
                    .fontWeight(.medium)
                   
                    .padding()
                Spacer()
               }
                
            }).frame(height: 100.0)
            .sheet(isPresented: $chuyenview, content: {
                dataview(message: $message)
            })
            
            
            
        }
    }
}

struct rowfood_Previews: PreviewProvider {
    static var previews: some View {
        rowfood(tu: listbai26[1] ).previewLayout(.fixed(width: 375, height: 100))
    }
}
