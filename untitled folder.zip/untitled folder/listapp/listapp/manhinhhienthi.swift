//
//  manhinhhienthi.swift
//  listapp
//
//  Created by USER on 2021/04/29.
//

import SwiftUI

struct manhinhhienthi: View {
    @Binding var message:Int
    
    
    
    var body: some View {
        NavigationView{
       
           
           
                
                //if message==26{
                List(listbai26){tu in
                    rowfood(tu: tu)}
                    .navigationBarItems(trailing: Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/, label: {
                        /*@START_MENU_TOKEN@*/Text("Button")/*@END_MENU_TOKEN@*/
                    }))
                    
               }
//                if message==27{
//                    List(listbai27){tu in
//                        rowfood(tu: tu)}
            
      
    
    }
}

struct manhinhhienthi_Previews: PreviewProvider {
    static var previews: some View {
        manhinhhienthi(message: .constant(0))
    }
}
