//
//  speech.swift
//  listapp
//
//  Created by USER on 2021/04/29.
//

import Foundation
import  AVFoundation
func readme(mytext:String,mylang:String){
    let utterance = AVSpeechUtterance(string: mytext)
    utterance.voice=AVSpeechSynthesisVoice(language: mylang)
    utterance.rate=0.5
    let systhesizer=AVSpeechSynthesizer()
    systhesizer.speak(utterance)
    
}
