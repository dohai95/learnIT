//
//  ContentView.swift
//  Testkanjii
//
//  Created by USER on 2021/08/10.
//

import SwiftUI

struct kanjiin5: View {
    @State private var mangmoi=hanvietn5
    @State private var mangluutru:[String]=[]
    @State private var correctanswer=Int.random(in: 0...3)
    @State private var socaudung=0
    @State private var ok=0
    @State private var count=0
    @State private var showalert=false
    @State private var chuyenmanhinh=false
    var body: some View {
        ZStack {
            VStack {
               
                HStack {
                    Text(String(socaudung)+"/")
                    Text(String(mangmoi.count))
                }
                //Text(kanjin5[hanvietn5.firstIndex(of: mangmoi[correctanswer])!])
                ForEach(0..<4){
                    num in Button(action: {
                        if num==correctanswer{
                            mangluutru.insert(kanjin5[hanvietn5.firstIndex(of: mangmoi[correctanswer])!], at: count)
                            count=count+1
                            socaudung=socaudung+1
                            self.random()
                        }
                        else{
                            showalert.toggle()
                        }
                    }, label: {
                        VStack {
                            Text(mangmoi[num])
                            Text("("+nghian5[hanvietn5.firstIndex(of: mangmoi[num])!]+")")
                        }.padding()
                    })
                    
                }.animation(/*@START_MENU_TOKEN@*/.easeIn/*@END_MENU_TOKEN@*/)
                
            }.alert(isPresented: $showalert, content: {
                Alert( title: Text(""), message: Text("Sai Rồi"), dismissButton: .cancel(Text("OK")))
            })
            
                VStack {
                    Text(kanjin5[hanvietn5.firstIndex(of: mangmoi[correctanswer])!])
                        .font(.largeTitle)
                        .padding(.top, 100.0)
                        .frame(width: nil)
                    Spacer()
                    Button(action: {
                        chuyenmanhinh.toggle()
                    }, label: {
                        Text("Button").fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/).foregroundColor(Color.white).frame(width: 200.0, height: 50).background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color.blue/*@END_MENU_TOKEN@*/)
                            
                    }).sheet(isPresented: $chuyenmanhinh, content: {
                        history(kanji: $mangluutru)
                    })
                }
        }.onAppear(perform: {
            test()
        })
        }
    
    func random() {
        correctanswer=Int.random(in: 0...3)
        mangmoi=hanvietn5.shuffled()
        
        for  a in 0...mangmoi.count
        {
            if kanjin5[hanvietn5.firstIndex(of: mangmoi[correctanswer])!]==mangluutru[a]{
                ok=ok+1
            }
            
        }
        while ok>0 {
            correctanswer=Int.random(in: 0...3)
            mangmoi=hanvietn5.shuffled()
            var b=0
            for  a in 0...mangmoi.count
            {
                if kanjin5[hanvietn5.firstIndex(of: mangmoi[correctanswer])!]==mangluutru[a]{
                    b=b+1
                }
                 
                
            }
            if b==0{
                ok=0
               
            }
        }
    }
    func test(){
        for a in 0..<mangmoi.count{
            mangluutru.insert(" ", at: a)
        }
    }
}


struct kanjiin5_Previews: PreviewProvider {
    static var previews: some View {
        kanjiin5()
    }
}
