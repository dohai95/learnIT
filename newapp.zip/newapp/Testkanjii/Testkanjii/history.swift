//
//  history.swift
//  Testkanjii
//
//  Created by USER on 2021/08/11.
//

import SwiftUI

struct history: View {
    @Binding var kanji:[String]
    var body: some View {
        List{
            ForEach(0..<kanji.count){num in
                Text(kanji[num])
            }
        }
    }
}

struct history_Previews: PreviewProvider {
    static var previews: some View {
        history(kanji: .constant([""]))
    }
}
