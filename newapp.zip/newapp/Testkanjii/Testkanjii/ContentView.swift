//
//  ContentView.swift
//  Testkanjii
//
//  Created by USER on 2021/08/10.
//

import SwiftUI

struct ContentView: View {
   @State private var chuyentrang=false
    var body: some View {
        VStack {
           
            Button(action: {chuyentrang.toggle()}, label: {
                Text("N5").font(.largeTitle)
            }).fullScreenCover(isPresented: $chuyentrang)  {
                NavigationView{
                kanjiin5().navigationBarItems(leading: Button("Back"){
                    chuyentrang=false
            })
                }
    }
}
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
