//
//  TestkanjiiApp.swift
//  Testkanjii
//
//  Created by USER on 2021/08/10.
//

import SwiftUI

@main
struct TestkanjiiApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
