//
//  ContentView.swift
//  testapi
//
//  Created by USER on 2021/08/07.
//

import SwiftUI
let geturl="http://apilayer.net/api/live?access_key=1175bafddf86ff71918455a39e021d2f&currencies=EUR,GBP,CAD,PLN&source=USD&format=1"
struct Model: Decodable {
    let success: Bool
    let terms, privacy: String
    let timestamp: Int
    let source: String
    let quotes: [String: Double]
}
struct ContentView: View {
    @ObservedObject var viewModel=ViewModel()
    //@State private var qouteData:QuoteData?
    var body: some View {
        NavigationView{
            VStack {
                Text(viewModel.items?.source ?? "hi")
            }.onAppear(perform: {
                viewModel.loadData()
            })
            .navigationBarTitle("DATA")
        }
            
           
       
    }
}
    class ViewModel: ObservableObject {
        @Published var items:Model?
    
     func loadData(){
        guard let url=URL(string: geturl) else {
            return
        }
        URLSession.shared.dataTask(with: url){
            (data,response,error) in
            do{
                if let data=data{
                    let decodeData=try JSONDecoder().decode(Model.self, from: data);                       DispatchQueue.main.async {
                            self.items=decodeData
                        }
                    }
                
                else{
                    print ("no data")
                }
            }
            catch(let error){
                print(error.localizedDescription)
            }
        
        }.resume()
    }
}

//struct QuoteData:Decodable {
//    var success:Bool
//    var terms:String
//    var privacy:String
//    var timestamp:Double
//    var source:String
//    var quotes:[Double]
//}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
