//
//  testapiApp.swift
//  testapi
//
//  Created by USER on 2021/08/07.
//

import SwiftUI

@main
struct testapiApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
