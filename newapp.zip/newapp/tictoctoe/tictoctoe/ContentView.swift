//
//  ContentView.swift
//  tictoctoe
//
//  Created by USER on 2021/08/20.
//

import SwiftUI

enum SquareStatus{
    case empty
    case home
    case visitor
}
class Square: ObservableObject {
    @Published var squareStatus:SquareStatus
    init(status:SquareStatus) {
        self.squareStatus=status
    }
}
class TictoctoeModel: ObservableObject {
    @Published var square=[Square]()
    
    init() {
        for _ in 0...8{
            square.append(Square(status: .empty))
        }
    }
    func reset() {
        for _ in 0...8{
            square.append(Square(status: .empty))
        }
    }
    var gameover:(SquareStatus, Bool){
        get{
            if thereiswinner != .empty{
                return(thereiswinner, true)
            }
            else {
                for i in 0...8{
                    if square[i].squareStatus == .empty{
                        return(.empty,false)
                    }
                }
                return(.empty,true)
            }
        }
    }
    private var thereiswinner:SquareStatus{
        get{
            if let check=self.checkindexes([0,1,2]){
                return check
            }
            else if let check=self.checkindexes([3,4,5]){
                return check
            }
            else if let check=self.checkindexes([6,7,8]){
                return check
            }
            else if let check=self.checkindexes([0,3,6]){
                return check
            }
            else if let check=self.checkindexes([1,4,7]){
                return check
            }
            else if let check=self.checkindexes([2,5,8]){
                return check
            }else if let check=self.checkindexes([0,4,8]){
                return check
            }
            else if let check=self.checkindexes([2,4,6]){
                return check
            }
            return .empty
            
        }
    }
    private func checkindexes(_ indexes:[Int])->SquareStatus?{
        var homeCounter:Int=0
        var visitorCounter:Int=0
        for index in indexes{
            let sq=square[index]
            if sq.squareStatus == .home{
                homeCounter += 1
                
            }else if sq.squareStatus == .visitor{
                visitorCounter += 1
            }
        }
        if homeCounter == 3 {
            return .home
        }
        else if visitorCounter == 3{
            return .visitor
        }
        return nil
    }
    private func moveAi(){
        var index = Int.random(in: 0...8)
        while makemove(index: index, player: .visitor) == false && gameover.1 == false{
            index = Int.random(in: 0...8)
        }
    }
    func makemove(index:Int, player:SquareStatus)->Bool{
        if square[index].squareStatus == .empty{
            square[index].squareStatus=player
            if player == .home{
                moveAi()
            }
            return true
            
        }
        return false
    }
}
struct SquareView:View {
    @ObservedObject var dataSource:Square
    var action:()->Void
    var body: some View{
        Button(action: {self.action()}, label: {
            Text(self.dataSource.squareStatus == .home ? "X":self.dataSource.squareStatus == .visitor ? "O" :" ")
                .font(.largeTitle)
                .bold()
                .foregroundColor(.blue)
                .frame(width: 70, height: 70, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                .background(Color.gray.opacity(0.3).cornerRadius(10))
                .padding()
        })
        }
    }


struct ContentView: View {
    @StateObject var tictoctoeModel=TictoctoeModel()
    @State var gameover:Bool=false
    func buttonAction(_ index:Int){
        _ = self.tictoctoeModel.makemove(index: index, player: .home)
        self.gameover = self.tictoctoeModel.gameover.1
    }
    var body: some View {
        VStack{
            ForEach(0..<tictoctoeModel.square.count/3,content: {
                row in HStack{
                    ForEach(0..<3,content: {
                        column in
                        let index=3 * row + column
                        SquareView(dataSource: tictoctoeModel.square[index],action: {self.buttonAction(index)})
                    })
                }
            })
            
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
