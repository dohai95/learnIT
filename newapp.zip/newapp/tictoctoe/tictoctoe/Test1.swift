//
//  Test1.swift
//  tictoctoe
//
//  Created by USER on 2021/08/21.
//

import SwiftUI

enum btnStatus {
    case pressed
    case notpress
}
class CheckPress: ObservableObject {
    @Published var press:btnStatus
    init(status:btnStatus) {
        self.press=btnStatus.notpress
    }
}
struct ModelView:View {
    var acion:()->Void
    var mangdudieu:[String]
    var index:Int
    var body: some View
    {
        Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/, label: {
            Text(mangdudieu[index])
                .frame(width: 70, height: 70, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                .foregroundColor(.white)
                .background(Color.blue)
    })
}
}
struct Test1: View {
    @State private var mang1=["0","1","2","3"]
    @State private var mang2=["0","1","2","3"]
    
    var body: some View {
        VStack{
            HStack{
                Text("1")
                }
            }
        }
    }


struct Test1_Previews: PreviewProvider {
    static var previews: some View {
        Test1()
    }
}
