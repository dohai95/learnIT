//
//  tictoctoeApp.swift
//  tictoctoe
//
//  Created by USER on 2021/08/20.
//

import SwiftUI

@main
struct tictoctoeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
