//
//  ContentView.swift
//  TestKanji
//
//  Created by USER on 2021/08/11.
//

import SwiftUI

struct ContentView: View {
    @State private var chuyenmanhinh=false
    @State private var number=0
    var body: some View {
        NavigationView{
            List{
                ForEach(1..<30){
                    num in Button(action: {
                        chuyenmanhinh.toggle()
                        number=num
                    }, label: {
                        Text("Day "+String(num))
                    }).fullScreenCover(isPresented: $chuyenmanhinh){
                        NavigationView{
                            Viewdata(number: $number).navigationBarItems(leading: Button("Back"){
                                chuyenmanhinh=false
                            })
                        }
                    }
                }
            }.navigationBarTitle(Text("TEST KANJI"))
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
