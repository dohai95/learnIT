//
//  Testview.swift
//  TestKanji
//
//  Created by USER on 2021/08/12.
//

import SwiftUI

struct Testview: View {
    @State private var correctanswer=Int.random(in: 0...3)
    @State private var ok=0
    @State private var count=0
    @State private var showalert=false
    @State private var mangluutru:[String]=[]
    @State private var mangmoi:[String]=[""]
    @State private var start=false
    @Binding var database:[String]
    @Binding var database1:[String]
    @Binding var database2:[String]
    @State private var chuyenmanhinh=false
    var body: some View {
        
        ZStack {
            Button(action: {
                start = true
                //random()
                mangmoi=database1.shuffled()
                reset()
               
              
               
                
            }, label: {
                Text("Start").font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/).foregroundColor(Color.white).frame(width: 300.0, height: 50.0).background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color.blue/*@END_MENU_TOKEN@*/).cornerRadius(10)
            }).opacity(start ? 0:1)
            VStack{
                
            
            if start==true{
                Text(database[database1.firstIndex(of: mangmoi[correctanswer])!]).padding().font(.largeTitle)
                Text(String(count)+"/"+String(mangluutru.count))
                ForEach(0..<4){
                    num in Button(action: {
                        if num == correctanswer{
                        
                         //mangluutru.insert(database[database1.firstIndex(of: mangmoi[num])!], at: count)
                            mangluutru[count]=database[database1.firstIndex(of: mangmoi[num])!]
                            
                            count=count+1
                           
                            if count<database.count{
                                self.random()
                            }
                            if count==database.count{
                                reset1()
                                count=0
                                self.random()
                            }
                            
                        }
                        else{
                            showalert.toggle()
                        }
                    }, label: {
                        VStack {
                            Text(mangmoi[num])
                            Text("("+database2[database1.firstIndex(of: mangmoi[num])!]+")")
                        }.padding()
                    })
            
                }.alert(isPresented: $showalert, content: {
                    Alert(title: Text(""), message: Text("Sai rồi"), dismissButton:.cancel(Text("OK")))
                })
                Button("check"){
                    chuyenmanhinh.toggle()
                }.sheet(isPresented: $chuyenmanhinh, content: {
                    check(mangcheck:$mangluutru)
                })
        }
            }
        }
        .onAppear(perform: {
            mangluutru = database
            reset1()
            reset()
        })
    
    }
    func random(){
        correctanswer=Int.random(in: 0...3)
        mangmoi=database1.shuffled()
        
        for  a in 0...database.count
        {
            if database[database1.firstIndex(of: mangmoi[correctanswer])!]==mangluutru[a]{
                ok=ok+1
            }
            
        }
        while ok>0 {
            //correctanswer=Int.random(in: 0...3)
            mangmoi=database1.shuffled()
            var b=0
            for  a in 0...database.count
            {
                if database[database1.firstIndex(of: mangmoi[correctanswer])!]==mangluutru[a]{
                    b=b+1
                }
                 
                
            }
            if b==0{
                ok=0
              
            }
           
        }
    }
    func reset() {
        for a in 0..<mangluutru.count{
            mangluutru.insert(" ", at: a)
        }
    }
    func reset1()  {
        for a in 0..<mangluutru.count{
            mangluutru[a]=" "
        }
    }
}

struct Testview_Previews: PreviewProvider {
    static var previews: some View {
        Testview(database:.constant(["読","半","四","間","雨"]),database1: .constant(["ĐỘC","BÁN","TỨ","GIAN","VŨ"]),database2: .constant(["đọc","nửa","bốn","thời gian","mưa"]))
    }
}
