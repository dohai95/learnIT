//
//  check.swift
//  TestKanji
//
//  Created by USER on 2021/08/13.
//

import SwiftUI

struct check: View {
    @Binding var mangcheck:[String]
    var body: some View {
        List{
            ForEach(0..<mangcheck.count){
                a in Text(mangcheck[a])
            }
        }
    }
}

struct check_Previews: PreviewProvider {
    static var previews: some View {
        check(mangcheck: .constant([""]))
    }
}
