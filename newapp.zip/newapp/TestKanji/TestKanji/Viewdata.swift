//
//  Viewdata.swift
//  TestKanji
//
//  Created by USER on 2021/08/11.
//

import SwiftUI

struct Viewdata: View {
    @State private var daynumber:[data]=day1
    @State private var mangdulieu:[String]=[]
    @State private var mangdulieu1:[String]=[]
    @State private var mangdulieu2:[String]=[]
    @State private var chuyendulieu:[String]=[]
    @State private var chuyendulieu1:[String]=[]
    @State private var chuyendulieu2:[String]=[]
    @Binding var number:Int
    @State private var chuyenmanhinh=false
    
    var body: some View {
        
            VStack {
                List(daynumber){
                tu in RowView(tu: tu)
                    
                }.navigationBarTitle(Text("Day "+String(number)))
                Button(action: {chuyenmanhinh.toggle()
                    test()
                    chuyendulieu=mangdulieu
                    chuyendulieu1=mangdulieu1
                    chuyendulieu2=mangdulieu2
                }
                       , label: {
                    Text("TEST").foregroundColor(Color.white).frame(width: 500.0, height: 50.0).background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color.blue/*@END_MENU_TOKEN@*/)
                       })
            }.onAppear(perform: {
                checkday()
               test1()
                
            })
            .fullScreenCover(isPresented: $chuyenmanhinh) {
                NavigationView{
                   // Testview(database: $chuyendulieu,database1: $chuyendulieu1,database2: $chuyendulieu2)
                    Testview2(mang1: $chuyendulieu, mang2: $mangdulieu1)
                        .navigationTitle(Text("Day "+String(number)))
                        .navigationBarItems(leading: Button("Back"){
                        chuyenmanhinh=false
                    })
                }
            }
    
    }
    func checkday() {
        switch number {
        case 1:
            daynumber=day1
        case 2:
            daynumber=day2
        case 3:
            daynumber=day3
        case 4:
            daynumber=day4
        default:
            daynumber=day1
        }
    }
   
    func test()  {
        for a in 0..<daynumber.count{
            mangdulieu[a]=daynumber[a].kanji
            mangdulieu1[a]=daynumber[a].hanviet
            mangdulieu2[a]=daynumber[a].nghia
        }
    }
    func test1() {
        for a in 0..<daynumber.count{
            mangdulieu.insert(" ", at: a)
            mangdulieu1.insert(" ", at: a)
            mangdulieu2.insert(" ", at: a)
        }
    }
}

struct Viewdata_Previews: PreviewProvider {
    static var previews: some View {
        Viewdata(number: .constant(0))
    }
}
