//
//  Data.swift
//  TestKanji
//
//  Created by USER on 2021/08/11.
//

import Foundation
struct data:Identifiable {
    var id:Int
    var kanji:String
    var hanviet:String
    var nghia:String
}


let day1=[
data(id: 0, kanji: "一", hanviet: "Nhất", nghia: "số một"),
data(id: 1, kanji: "二", hanviet: "Nhị", nghia: "số hai"),
data(id: 2, kanji: "三", hanviet: "Tam", nghia: "số ba"),
data(id: 3, kanji: "四", hanviet: "Tứ", nghia: "số bốn"),
    data(id: 4, kanji: "五", hanviet: "Ngũ", nghia: "số năm"),
    data(id: 5, kanji: "六", hanviet: "Lục", nghia: "số sáu"),
    data(id: 6, kanji: "七", hanviet: "Thất", nghia: "số bảy"),
    data(id: 7, kanji: "八", hanviet: "Bát", nghia: "số tám"),
    data(id: 8, kanji: " 九", hanviet: "Cửu", nghia: "số chín"),
    data(id: 9, kanji: "十", hanviet: "Thập", nghia: "số mười"),
    data(id: 10, kanji: "百", hanviet: "Bách", nghia: "một trăm"),
    data(id: 11, kanji: "千", hanviet: "Thiên", nghia: "một nghìn"),
    data(id: 12, kanji: "万", hanviet: "Vạn", nghia: "mười nghìn"),
    data(id: 13, kanji: "億", hanviet: "Ức", nghia: "một trăm triệu"),
    data(id: 14, kanji: "兆", hanviet: "Triệu", nghia: "một nghìn tỷ"),
    data(id: 15, kanji: " 金", hanviet: "Kim", nghia: "vàng"),
    data(id: 16, kanji: " 木", hanviet: "Mộc", nghia: "cây"),
    data(id: 17, kanji: " 水", hanviet: "Thủy", nghia: "nước"),
    data(id: 18, kanji: " 火", hanviet: "Hỏa", nghia: "lửa"),
    data(id: 19, kanji: " 土", hanviet: "Thổ", nghia: "đất"),
    data(id: 20, kanji: " 上", hanviet: "Thượng", nghia: "trên"),
    data(id: 21, kanji: " 下", hanviet: "Hạ", nghia: "dưới"),
    data(id: 22, kanji: " 左", hanviet: "Tả", nghia: "trái"),
    data(id: 23, kanji: " 右", hanviet: "Hữu", nghia: "phải"),
    data(id: 24, kanji: " 石", hanviet: "Thạch", nghia: "viên đá"),

]
 let day2=[
  data(id: 0, kanji: "東", hanviet: "Đông", nghia: "phía đông"),
    data(id: 1, kanji: "西", hanviet: "Tây", nghia: "phía tây"),
    data(id: 2, kanji: "南", hanviet: "Nam", nghia: "phía nam"),
    data(id: 3, kanji: "北", hanviet: "Bắc", nghia: "phía bắc"),
    data(id: 4, kanji: "中", hanviet: "Trung", nghia: "trung tâm"),
    data(id: 5, kanji: "天", hanviet: "Thiên", nghia: "trời"),
    data(id: 6, kanji: "地", hanviet: "Địa", nghia: "đất"),
    data(id: 7, kanji: "池", hanviet: "Trì", nghia: "cái ao"),
    data(id: 8, kanji: "汽", hanviet: "Khí", nghia: "hơi nước"),
    data(id: 9, kanji: "気", hanviet: "Khí", nghia: "không khí"),
    data(id: 10, kanji: "円", hanviet: "Viên", nghia: "hình tròn"),
    data(id: 11, kanji: "雨", hanviet: "Vũ", nghia: "mưa"),
    data(id: 12, kanji: "士", hanviet: "Sĩ", nghia: "nhân sĩ"),
    data(id: 13, kanji: "仕", hanviet: "Sĩ", nghia: "công việc"),
    data(id: 14, kanji: "己", hanviet: "Kỉ", nghia: "bản thân"),
    data(id: 15, kanji: "人", hanviet: "Nhân", nghia: "người"),
    data(id: 16, kanji: "了", hanviet: "Liễu", nghia: "kết thúc"),
    data(id: 17, kanji: "子", hanviet: "Tử", nghia: "con"),
    data(id: 18, kanji: "字", hanviet: "Tự", nghia: "chữ"),
    data(id: 19, kanji: "学", hanviet: "Học", nghia: "học tập"),
    data(id: 20, kanji: "大", hanviet: "Đại", nghia: "to lớn"),
    data(id: 21, kanji: "天", hanviet: "Thiên", nghia: "trời"),
    data(id: 22, kanji: "夫", hanviet: "Phu", nghia: "chồng"),
    data(id: 23, kanji: "太", hanviet: "Thái", nghia: "béo"),
    data(id: 24, kanji: "犬", hanviet: "Khuyển", nghia: "chó"),

 ]
let day3=[
    data(id: 0, kanji: "矢", hanviet: "Thỉ", nghia: "mũi tên"),
    data(id: 1, kanji: "失", hanviet: "Thất", nghia: "thất bại"),
    data(id: 2, kanji: "竹", hanviet: "Trúc", nghia: "cây trúc"),
    data(id: 3, kanji: "村", hanviet: "Thôn", nghia: "thôn làng"),
    data(id: 4, kanji: "王", hanviet: "Vương", nghia: "vua chúa"),
    data(id: 5, kanji: "玉", hanviet: "Ngọc", nghia: "viên ngọc"),
    data(id: 6, kanji: "宝", hanviet: "Bảo", nghia: "bảo vật"),
    data(id: 7, kanji: "国", hanviet: "Quốc", nghia: "quốc gia"),
    data(id: 8, kanji: "山", hanviet: "Sơn", nghia: "ngọn núi"),
    data(id: 9, kanji: "海", hanviet: "Hải", nghia: "biển"),
    data(id: 10, kanji: "林", hanviet: "Lâm", nghia: "rừng"),
    data(id: 11, kanji: "森", hanviet: "Sâm", nghia: "rừng sâu"),
    data(id: 12, kanji: "目", hanviet: "Mục", nghia: "mắt"),
    data(id: 13, kanji: "見", hanviet: "Kiến", nghia: "nhìn"),
    data(id: 14, kanji: "覚", hanviet: "Giác", nghia: "nhớ ra"),
    data(id: 15, kanji: "帰", hanviet: "Quy", nghia: "trở về"),
    data(id: 16, kanji: "貝", hanviet: "Bối", nghia: "con sò"),
    data(id: 17, kanji: "糸", hanviet: "Mịch", nghia: "sợi tơ"),
    data(id: 18, kanji: "線", hanviet: "Tuyến", nghia: "tuyến đường"),
    data(id: 19, kanji: "組", hanviet: "Tổ", nghia: "tổ chức"),
]
let day4=[
data(id: 0, kanji: "父", hanviet: "Phụ", nghia: "cha"),
data(id: 1, kanji: "母", hanviet: "Mẫu", nghia: "mẹ"),
data(id: 2, kanji: "日", hanviet: "Nhật", nghia: "ngày, mặt trời"),
data(id: 3, kanji: "月", hanviet: "Nguyệt", nghia: "trăng, tháng"),
    data(id: 4, kanji: "年", hanviet: "Niên", nghia: "năm"),
    data(id: 5, kanji: "口", hanviet: "Khẩu", nghia: "miệng"),
    data(id: 6, kanji: "図", hanviet: "Đồ", nghia: "bản đồ"),
    data(id: 7, kanji: "豆", hanviet: "Đậu", nghia: "hạt đậu"),
    data(id: 8, kanji: " 耳", hanviet: "Nhĩ", nghia: "cái tai"),
    data(id: 9, kanji: "音", hanviet: "Âm", nghia: "âm thanh"),
    data(id: 10, kanji: "手", hanviet: "Thủ", nghia: "cái tay"),
    data(id: 11, kanji: "毛", hanviet: "Mao", nghia: "cái lông"),
    data(id: 12, kanji: "足", hanviet: "Túc", nghia: "cái chân"),
    data(id: 13, kanji: "走", hanviet: "Tẩu", nghia: "chạy"),
    data(id: 14, kanji: "頭", hanviet: "Đầu", nghia: "cái đầu"),
    data(id: 15, kanji: "心", hanviet: "Tâm", nghia: "trái tim"),
    data(id: 16, kanji: "思", hanviet: "Tư", nghia: "suy nghĩ"),
    data(id: 17, kanji: "田", hanviet: "Điền", nghia: "ruộng"),
    data(id: 18, kanji: "細", hanviet: "Tế", nghia: "tế bào"),
    data(id: 19, kanji: "紙", hanviet: "Chỉ", nghia: "tờ giấy"),
    data(id: 20, kanji: "車", hanviet: "Xa", nghia: "xe"),
    data(id: 21, kanji: "出", hanviet: "Xuất", nghia: "đi ra"),
    data(id: 22, kanji: "入", hanviet: "Nhập", nghia: "đi vào"),
    data(id: 23, kanji: "込", hanviet: "Nhập", nghia: "đông đúc"),
    data(id: 24, kanji: " 友", hanviet: "Hữu", nghia: "bạn hữu"),

]



