//
//  TestKanjiApp.swift
//  TestKanji
//
//  Created by USER on 2021/08/11.
//

import SwiftUI

@main
struct TestKanjiApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
