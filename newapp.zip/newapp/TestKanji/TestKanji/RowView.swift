//
//  RowView.swift
//  TestKanji
//
//  Created by USER on 2021/08/11.
//

import SwiftUI

struct RowView: View {
    var tu:data
    var body: some View {
        HStack {
            Text(tu.kanji)
                .font(.largeTitle)
                .padding()
            VStack{
                Text(tu.hanviet)
                Text("("+tu.nghia+")")
            }
            Spacer()
        }
    }
}

struct RowView_Previews: PreviewProvider {
    static var previews: some View {
        RowView(tu: day1[0])
    }
}
