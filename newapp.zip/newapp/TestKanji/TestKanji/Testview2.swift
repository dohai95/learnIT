//
//  Testview2.swift
//  TestKanji
//
//  Created by USER on 2021/08/16.
//

import SwiftUI

struct Testview2: View {
    @Binding var mang1:[String]
    @Binding var mang2:[String]
    @State private var kanji1=[String](repeating: " ", count:5)
    @State private var hanviet1=[String](repeating: " ", count:5)
    @State private var testkanji=[String](repeating: " ", count:5)
    @State private var testhanviet=[String](repeating: " ", count:5)
    @State private var press=false
    @State private var bienluu:Int=0
    @State var pushalert=false
    @State var correct=false
    @State var alertstring=""
    @State var press1=0
    @State var press2=0
    @State var press3=0
    @State var press4=0
    @State var press5=0
    @State var press11=0
    @State var press12=0
    @State var press13=0
    @State var press14=0
    @State var press15=0
    @State var choice1=0
    @State var choice2=0
    var body: some View {
        VStack {
            Text(String(choice1))
            Text(String(choice2))
            
            HStack {
                VStack {
                    Button(action: {
                        press1=1
                        choice1=kanji1.firstIndex(of: testkanji[0])!
                    }, label: {
                        Text(testkanji[0])
                            .frame(width: 150, height: 50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                            .foregroundColor(.white)
                            .background(press1 == 1 ? Color.green:press1 == 3 ? Color.red:Color.blue)
                    })
                    Button(action: {
                        press2=1
                        choice1=kanji1.firstIndex(of: testkanji[1])!
                    }, label: {
                        Text(testkanji[1])
                            .frame(width: 150, height: 50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                            .foregroundColor(.white)
                            .background(press2 == 1 ? Color.green:press2 == 3 ? Color.red:Color.blue)
                            .padding()
                    })
                    Button(action: {
                        press3=1
                        choice1=kanji1.firstIndex(of: testkanji[2])!
                    }, label: {
                        Text(testkanji[2])
                            .frame(width: 150, height: 50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                            .foregroundColor(.white)
                            .background(press3 == 1 ? Color.green:press3 == 3 ? Color.red:Color.blue)
                    })
                    Button(action: {
                            press4=1
                            choice1=kanji1.firstIndex(of: testkanji[3])!}, label: {
                        Text(testkanji[3])
                            .frame(width: 150, height: 50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                            .foregroundColor(.white)
                            .background(press4 == 1 ? Color.green:press4 == 3 ? Color.red:Color.blue)
                            .padding()
                    })
                    Button(action: {
                        press5=1
                        choice1=kanji1.firstIndex(of: testkanji[4])!
                    }, label: {
                        Text(testkanji[4])
                            .frame(width: 150, height: 50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                            .foregroundColor(.white)
                            .background(press5 == 1 ? Color.green:press5 == 3 ? Color.red:Color.blue)
                            
                    })
                }
                VStack {
                    Button(action: {
                        press11=2
                        choice2=hanviet1.firstIndex(of: testhanviet[0])!
                    }, label: {
                        Text(testhanviet[0])
                            .frame(width: 150, height: 50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                            .foregroundColor(.white)
                            .background(press11 == 2 ? Color.green:press11 == 3 ? Color.red:Color.blue)
                    })
                    Button(action: {choice2=hanviet1.firstIndex(of: testhanviet[1])!}, label: {
                        Text(testhanviet[1])
                            .frame(width: 150, height: 50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                            .foregroundColor(.white)
                            .background(press12 == 2 ? Color.green:press12 == 3 ? Color.red:Color.blue)
                            .padding()
                    })
                    Button(action: {
                        choice2=hanviet1.firstIndex(of: testhanviet[2])!
                    }, label: {
                        Text(testhanviet[2])
                            .frame(width: 150, height: 50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                            .foregroundColor(.white)
                            .background(press13 == 2 ? Color.green:press13 == 3 ? Color.red:Color.blue)
                    })
                    Button(action: {
                        choice2=hanviet1.firstIndex(of: testhanviet[3])!
                    }, label: {
                        Text(testhanviet[3])
                            .frame(width: 150, height: 50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                            .foregroundColor(.white)
                            .background(press14 == 2 ? Color.green:press14 == 3 ? Color.red:Color.blue)
                            .padding()
                    })
                    Button(action: {choice2=hanviet1.firstIndex(of: testhanviet[4])!}, label: {
                        Text(testhanviet[4])
                            .frame(width: 150, height: 50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                            .foregroundColor(.white)
                            .background(press15 == 2 ? Color.green:press15 == 3 ? Color.red:Color.blue)
                           
                    })
                }
            }.onAppear(perform: {
                chuyendulieu()
                random()
        })
        }
        }
    
    func chuyendulieu() {
        for i in 0...4{
            kanji1[i]=mang1[i]
            hanviet1[i]=mang2[i]
        }
    }
    func random() {
       testkanji = kanji1.shuffled()
        testhanviet=hanviet1.shuffled()
    }
}

struct Testview2_Previews: PreviewProvider {
    static var previews: some View {
        Testview2(mang1: .constant(["読","半","四","間","雨"]), mang2: .constant(["ĐỘC","BÁN","TỨ","GIAN","VŨ"]))
    }
}
