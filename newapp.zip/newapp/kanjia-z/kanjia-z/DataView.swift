//
//  DataView.swift
//  kanjia-z
//
//  Created by USER on 2021/07/30.
//

import SwiftUI

struct DataView: View {
    @Binding var link:String
    @Binding var hanviet:String
    @Binding var kun:String
    @Binding var on:String
    @Binding var kanjii:String
    @Binding var tulienquan:[String]
    var body: some View {
        VStack {
            HStack {
                VStack{
                    Text(kanjii)
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(Color.blue)
                    Text(hanviet)
                        .font(.largeTitle)
                }.padding()
                
                
                Group{
                   SwiftUIWebView(url: URL(string: link))
                }.frame(width: 200, height: 200, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                Spacer()
            }
            
            HStack {
                Text("kun : ").padding(.leading)
                Text(kun)
                Spacer()
            }
            HStack {
                Text("on : ").padding(.leading)
                Text(on)
                Spacer()
            }
            VStack{
                List{
                    ForEach(0..<tulienquan.count){
                   
                        tu in Text(tulienquan[tu])
                    
                    }
                }
            }
            Spacer()
        }
    }
}

struct DataView_Previews: PreviewProvider {
    static var previews: some View {
        DataView(link: .constant(""), hanviet: .constant("nhat"),kun: .constant("ichi"),on: .constant(""), kanjii: .constant("一"), tulienquan: .constant([""]))
    }
}
