//
//  Rowview.swift
//  kanjia-z
//
//  Created by USER on 2021/07/30.
//

import SwiftUI

struct Rowview: View {
    var tu:data
    var body: some View {
        HStack {
            Text(tu.kanji+" ")
            Text(tu.hanviet)
        }
    }
}

struct Rowview_Previews: PreviewProvider {
    static var previews: some View {
        Rowview(tu: kanjii300[0]).previewLayout(.fixed(width: 375, height: 100))
    }
}
