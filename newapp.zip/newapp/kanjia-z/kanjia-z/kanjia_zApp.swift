//
//  kanjia_zApp.swift
//  kanjia-z
//
//  Created by USER on 2021/07/30.
//

import SwiftUI

@main
struct kanjia_zApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
