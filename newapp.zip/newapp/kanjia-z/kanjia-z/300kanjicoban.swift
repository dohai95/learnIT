//
//  300kanjicoban.swift
//  kanjia-z
//
//  Created by USER on 2021/07/30.
//

import Foundation
struct data:Identifiable {
    var id:Int
    var kanji:String
    var hanviet:String
    var kakikata:String
    var kun:String
    var on:String
    var tulienquan:[String]
    var nghia:String
    
}
let kanjii300=[
    data(id: 0, kanji: "一",hanviet: "Nhất", kakikata: "https://kakijun.jp/gif/0101200.gif", kun: "ひとー、ひとつ", on: "いち、いつ", tulienquan: ["一人ーひとり""一期","一時"],nghia:"Số một"),
    data(id: 1, kanji: "二", hanviet: "Nhị", kakikata: "https://kakijun.jp/gif/0205200.gif", kun: "ふた　ふたつ　ふたたび", on: "に、じ", tulienquan: ["二人ーふたり、二つーふたつ、二女ーじじょ、二位ーにばい"],nghia:"Số hai"),
    data(id: 2, kanji: "三", hanviet: "Tam", kakikata: "https://kakijun.jp/gif/0302200.gif", kun: "み み（つ） みっ（つ）", on: "サン", tulienquan: ["三つーみっつ、三重ーみえ、三位ーさんばい"],nghia:"Số ba"),
    data(id: 3, kanji: "四", hanviet: "Tứ", kakikata: "https://kakijun.jp/gif/0302200.gif", kun: "よ、よつ、よっつ、よん", on: "し", tulienquan: ["四つーよっつ、四つ葉ーよつば、四時ーよじ、四季ーしき"],nghia:"Số bốn"),
    data(id: 4, kanji: "五", hanviet: "Ngũ", kakikata: "https://kakijun.jp/gif/0302200.gif", kun: "いつ、いつつ", on: "ご", tulienquan: ["五つーいつつ、五日ーいつか、5倍ーごばい"],nghia:"Số năm"),
    data(id: 5, kanji: "六", hanviet: "Lục", kakikata: "https://kakijun.jp/gif/0302200.gif", kun: "む、むつ、むっつ、むい", on: "ろく、りく", tulienquan: ["六つーむっつ、六日ーむいか、六時ーろくじ、六書ーりくしょ"],nghia:"Số sáu"),
    data(id: 6, kanji: "七", hanviet: "Thất", kakikata: "https://kakijun.jp/gif/0302200.gif", kun: "なな、ななつ、なの", on: "しち", tulienquan: ["七つーななつ、七日ーなのか、七月ーしちがつ"],nghia:"Số bảy"),
    data(id: 7, kanji: "八", hanviet: "Bát", kakikata: "https://kakijun.jp/gif/0302200.gif", kun: "み み（つ） みっ（つ）", on: "サン", tulienquan: [""],nghia:"Số tám"),
    data(id: 8, kanji: "九", hanviet: "Cửu", kakikata: "https://kakijun.jp/gif/0302200.gif", kun: "み み（つ） みっ（つ）", on: "サン", tulienquan: [""],nghia:"Số chín"),
    data(id: 9, kanji: "十", hanviet: "Thập", kakikata: "https://kakijun.jp/gif/0302200.gif", kun: "み み（つ） みっ（つ）", on: "サン", tulienquan: [""],nghia:"Số mười"),
    data(id: 10, kanji: "百", hanviet: "Bách", kakikata: "https://kakijun.jp/gif/0302200.gif", kun: "み み（つ） みっ（つ）", on: "サン", tulienquan: [""],nghia:"Một trăm"),
    data(id: 11, kanji: "千", hanviet: "Thiên", kakikata: "https://kakijun.jp/gif/0302200.gif", kun: "み み（つ） みっ（つ）", on: "サン", tulienquan: [""],nghia:"Một nghìn"),
    data(id: 12, kanji: "万", hanviet: "Vạn", kakikata: "https://kakijun.jp/gif/0302200.gif", kun: "み み（つ） みっ（つ）", on: "サン", tulienquan: [""],nghia:"Mười nghìn"),
    data(id: 13, kanji: "億", hanviet: "Ức", kakikata: "https://kakijun.jp/gif/0302200.gif", kun: "み み（つ） みっ（つ）", on: "サン", tulienquan: [""],nghia:"Một trăm triệu"),
    data(id: 14, kanji: "兆", hanviet: "Triệu", kakikata: "https://kakijun.jp/gif/0302200.gif", kun: "み み（つ） みっ（つ）", on: "サン", tulienquan: [""],nghia:"Một nghìn tỷ"),
    data(id: 15, kanji: "金", hanviet: "Kim", kakikata: "https://kakijun.jp/gif/0302200.gif", kun: "み み（つ） みっ（つ）", on: "サン", tulienquan: [""],nghia:"Vàng"),
    data(id: 16, kanji: "木", hanviet: "Mộc", kakikata: "https://kakijun.jp/gif/0302200.gif", kun: "み み（つ） みっ（つ）", on: "サン", tulienquan: [""],nghia:"Cây"),
    data(id: 17, kanji: "水", hanviet: "Thuỷ", kakikata: "https://kakijun.jp/gif/0302200.gif", kun: "み み（つ） みっ（つ）", on: "サン", tulienquan: [""],nghia:"Nước"),
    data(id: 18, kanji: "火", hanviet: "Hoả", kakikata: "https://kakijun.jp/gif/0302200.gif", kun: "み み（つ） みっ（つ）", on: "サン", tulienquan: [""],nghia:"Lửa"),
    data(id: 19, kanji: "土", hanviet: "Thổ", kakikata: "https://kakijun.jp/gif/0302200.gif", kun: "み み（つ） みっ（つ）", on: "サン", tulienquan: [""],nghia:"Đất"),
    data(id: 20, kanji: "上", hanviet: "Thượng", kakikata: "https://kakijun.jp/gif/0302200.gif", kun: "み み（つ） みっ（つ）", on: "サン", tulienquan: [""],nghia:"Trên"),
    data(id: 21, kanji: "下", hanviet: "Hạ", kakikata: "https://kakijun.jp/gif/0302200.gif", kun: "み み（つ） みっ（つ）", on: "サン", tulienquan: [""],nghia:"Dưới"),
    data(id: 22, kanji: "左", hanviet: "Tả", kakikata: "https://kakijun.jp/gif/0302200.gif", kun: "み み（つ） みっ（つ）", on: "サン", tulienquan: [""],nghia:"Trái"),
    data(id: 23, kanji: "右", hanviet: "Hữu", kakikata: "https://kakijun.jp/gif/0302200.gif", kun: "み み（つ） みっ（つ）", on: "サン", tulienquan: [""],nghia:"Phải"),
    data(id: 24, kanji: "石", hanviet: "Thạch", kakikata: "https://kakijun.jp/gif/0302200.gif", kun: "み み（つ） みっ（つ）", on: "サン", tulienquan: [""],nghia:"Hòn đá")
]
