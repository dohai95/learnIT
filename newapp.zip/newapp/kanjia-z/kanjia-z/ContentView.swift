//
//  ContentView.swift
//  kanjia-z
//
//  Created by USER on 2021/07/30.
//

import SwiftUI

struct ContentView: View {
    @State private var kanjii=""
    @State private var link=""
    @State private var hanviet=""
    @State private var kun=""
    @State private var on=""
    @State private var tulienquan:[String]=[""]
    @State private var chuyentrang=false
    var body: some View {
       
        NavigationView{
            List{
                ForEach(kanjii300){
                    tu in Button(action: {link=tu.kakikata
                        hanviet=tu.hanviet
                        kanjii=tu.kanji
                        kun=tu.kun
                        on=tu.on
                        tulienquan=tu.tulienquan
                        chuyentrang.toggle()
                    }, label: {
                        Text(tu.kanji+" "+tu.hanviet)
                    }).sheet(isPresented: $chuyentrang, content: {
                        DataView(link: $link, hanviet: $hanviet,kun:$kun,on:$on,kanjii: $kanjii, tulienquan: $tulienquan)
                    })
                }
            }.navigationTitle("300kanji")
        }
        }
    }


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
